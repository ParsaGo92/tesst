import os

API_ID = int(os.getenv("API_ID", "28135459"))
API_HASH = os.getenv("API_HASH", "ffb0975a70486423176252f6a004e5a2")
if not API_ID or not API_HASH:
    raise ValueError("API_ID and API_HASH environment variables are required")

CHECK_INTERVAL = float(os.getenv("CHECK_INTERVAL", "10.0"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
RETRY_DELAY = float(os.getenv("RETRY_DELAY", "5.0"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"