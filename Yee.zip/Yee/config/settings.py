import os
BOT_TOKEN = os.getenv("BOT_TOKEN", "7354915525:AAGdYyLg6LbH7LaibVf1_Jp3jwi3f5mTzzA")
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN environment variable is required")

CHECK_INTERVAL = float(os.getenv("CHECK_INTERVAL", "10.0"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
RETRY_DELAY = float(os.getenv("RETRY_DELAY", "5.0"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
