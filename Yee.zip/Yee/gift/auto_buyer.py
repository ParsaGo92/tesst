
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

from database.user_manager import user_data_manager
from gift.loader import gift_loader
from gift.sender import get_gift_sender, GiftFilter
from gift.sync import get_gift_sync_manager

logger = logging.getLogger(__name__)

class AutoBuyTask:
    def __init__(self, bot, check_interval: int = 30):
        self.bot = bot
        self.check_interval = check_interval
        self.running = False
        self.task = None
        self.gift_sender = get_gift_sender(bot)
    
    async def start(self):
        if not self.running:
            self.running = True
            self.task = asyncio.create_task(self._autobuy_loop())
            
            sync_manager = await get_gift_sync_manager()
            sync_manager.add_listener(self._process_new_gifts)
            await sync_manager.start()
            
            logger.info("AutoBuy task started with real-time gift sync")
    
    async def stop(self):
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            logger.info("AutoBuy task stopped")
    
    async def _autobuy_loop(self):
        while self.running:
            try:
                await self._process_autobuy_cycle()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in autobuy loop: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _process_autobuy_cycle(self):
        autobuy_users = await user_data_manager.get_all_autobuy_users()
        
        for user_data in autobuy_users:
            try:
                await self._process_user_autobuy(user_data)
            except Exception as e:
                logger.error(f"Error processing autobuy for user {user_data['user_id']}: {e}")
    
    async def _process_user_autobuy(self, user_data: Dict[str, Any]):
        user_id = user_data['user_id']
        buyable_gifts = await gift_loader.get_buyable_gifts(
            user_balance=user_data['stars_balance'],
            filter_limited_only=user_data['filter_enabled'],
            max_price=user_data['max_price_limit'],
            min_price=user_data.get('min_price_limit', 0),
            max_count=user_data['max_buy_per_cycle']
        )
        
        if not buyable_gifts:
            return
        
        total_spent = 0
        purchased_gifts = []
        max_gifts_per_cycle = user_data['max_buy_per_cycle']
        
        for gift in buyable_gifts[:max_gifts_per_cycle]:
            gift_cost = gift.get('stars', 0)
            gift_id = str(gift.get('gift_id', gift.get('id', 'Unknown')))
            
            current_user_data = await user_data_manager.get_user_data(user_id)
            is_eligible, reason = GiftFilter.check_gift_eligibility(gift, current_user_data)
            if not is_eligible:
                logger.info(f"Skipping gift {gift_id} for user {user_id}: {reason}")
                continue
            
            try:
                success = await self.gift_sender.send_gift_to_user(
                    user_id=user_id,
                    gift_id=gift_id
                )
                
                if success:
                    balance_success = await user_data_manager.spend_stars(user_id, gift_cost)
                    if balance_success:
                        total_spent += gift_cost
                        purchased_gifts.append(gift)
                        logger.info(f"✓ Gift {gift_id} sent to user {user_id} for {gift_cost} stars")
                    else:
                        logger.error(f"Gift sent but failed to deduct balance for user {user_id}")
                else:
                    logger.warning(f"Failed to send gift {gift_id} to user {user_id}")
            except Exception as e:
                logger.error(f"Error processing gift {gift_id} for user {user_id}: {e}")
                continue
        
        if purchased_gifts:
            await self._send_purchase_notification(user_id, purchased_gifts, total_spent)
    
    async def _send_gift_notification(self, user_id: int, gift: dict):
        try:
            gift_id = gift.get('gift_id', 'Unknown')
            stars = gift.get('stars', 0)
            available = gift.get('available_amount', 0)
            is_limited = gift.get('is_limited', False)
            
            gift_type = "Limited" if is_limited else "Unlimited"
            message = f"Gift Available: {gift_type} gift_id = {gift_id}, stars = {stars}"
            if is_limited:
                message += f", available = {available}"
            
            await self.bot.send_message(user_id, message)
            
        except Exception as e:
            logger.error(f"Failed to send notification to user {user_id}: {e}")
            
    async def _send_purchase_notification(self, user_id: int, gifts: list, total_spent: int):
        try:
            for gift in gifts:
                gift_id = gift.get('gift_id', gift.get('id', 'Unknown'))
                stars = gift.get('stars', 0)
                is_limited = gift.get('is_limited', False)
                
                gift_type = "Limited" if is_limited else "Unlimited"
                message = f"🎁 Auto gift purchased!\n\n"
                message += f"Type: {gift_type}\n"
                message += f"Gift ID: {gift_id}\n"
                message += f"Cost: {stars} stars"
                
                if is_limited:
                    available = gift.get('available_amount', 0)
                    total = gift.get('total_amount', 0)
                    message += f"\nAvailability: {available}/{total}"
                
                await self.bot.send_message(user_id, message)
            
        except Exception as e:
            logger.error(f"Failed to send notification to user {user_id}: {e}")
    
    async def _process_new_gifts(self, new_gifts: list):
        try:
            logger.info(f"🔥 Processing {len(new_gifts)} new gifts for AutoBuy")
            
            autobuy_users = await user_data_manager.get_all_autobuy_users()
            
            for user_data in autobuy_users:
                await self._process_user_new_gifts(user_data, new_gifts)
                
        except Exception as e:
            logger.error(f"Error processing new gifts: {e}")
    
    async def _process_user_new_gifts(self, user_data: dict, new_gifts: list):
        try:
            user_id = user_data['user_id']
            
            eligible_gifts = []
            for gift in new_gifts:
                is_eligible, reason = GiftFilter.check_gift_eligibility(gift, user_data)
                if is_eligible:
                    eligible_gifts.append(gift)
            
            if not eligible_gifts:
                return
                
            max_purchases = user_data.get('max_buy_per_cycle', 1)
            purchased_gifts = []
            
            for gift in eligible_gifts[:max_purchases]:
                gift_price = gift.get('stars', 0)
                gift_id = str(gift.get('gift_id', gift.get('id', 'Unknown')))
                
                if user_data['stars_balance'] >= gift_price:
                    success = await self.gift_sender.send_gift_to_user(user_id, gift_id)
                    if success:
                        await user_data_manager.spend_stars(user_id, gift_price)
                        purchased_gifts.append(gift)
                        user_data['stars_balance'] -= gift_price
                        
                        logger.info(f"🎁 Auto-purchased gift {gift_id} for user {user_id}")
                    else:
                        logger.warning(f"Failed to purchase gift {gift_id} for user {user_id}")
                else:
                    logger.info(f"User {user_id} has insufficient balance for gift {gift_id}")
                    break
            
            if purchased_gifts:
                total_spent = sum(gift.get('stars', 0) for gift in purchased_gifts)
                await self._send_purchase_notification(user_id, purchased_gifts, total_spent)
                
        except Exception as e:
            logger.error(f"Error processing new gifts for user {user_data['user_id']}: {e}")


autobuy_task = None

def get_autobuy_task(bot) -> AutoBuyTask:
    global autobuy_task
    if autobuy_task is None:
        autobuy_task = AutoBuyTask(bot)
    return autobuy_task