import asyncio
import json
import logging
from pathlib import Path
from typing import Set, Dict, Any, Callable
from datetime import datetime

logger = logging.getLogger(__name__)

class GiftSyncManager:
    def __init__(self, gift_file_path: str = "data/gifts.json"):
        self.gift_file_path = Path(gift_file_path)
        self.last_modified = None
        self.known_gifts: Set[str] = set()
        self.listeners: list[Callable] = []
        self.running = False
        self.task = None
        
    def add_listener(self, callback: Callable):
        self.listeners.append(callback)
        
    async def start(self):
        if not self.running:
            self.running = True
            await self._load_existing_gifts()
            self.task = asyncio.create_task(self._monitor_loop())
            logger.info("Gift sync manager started")
    
    async def stop(self):
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            logger.info("Gift sync manager stopped")
    
    async def _load_existing_gifts(self):
        try:
            if self.gift_file_path.exists():
                self.last_modified = self.gift_file_path.stat().st_mtime
                
                with open(self.gift_file_path, 'r', encoding='utf-8') as f:
                    gifts_data = json.load(f)
                    
                if isinstance(gifts_data, list):
                    for gift in gifts_data:
                        gift_id = str(gift.get('gift_id', gift.get('id', '')))
                        if gift_id:
                            self.known_gifts.add(gift_id)
                elif isinstance(gifts_data, dict):
                    for gift_id, gift_data in gifts_data.items():
                        self.known_gifts.add(str(gift_id))
                        
                logger.info(f"Loaded {len(self.known_gifts)} existing gifts for sync")
        except Exception as e:
            logger.error(f"Error loading existing gifts for sync: {e}")
    
    async def _monitor_loop(self):
        while self.running:
            try:
                await self._check_for_changes()
                await asyncio.sleep(2)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in gift sync monitor: {e}")
                await asyncio.sleep(5)
    
    async def _check_for_changes(self):
        try:
            if not self.gift_file_path.exists():
                return
                
            current_modified = self.gift_file_path.stat().st_mtime
            
            if self.last_modified is None or current_modified > self.last_modified:
                self.last_modified = current_modified
                await self._process_file_changes()
                
        except Exception as e:
            logger.error(f"Error checking file changes: {e}")
    
    async def _process_file_changes(self):
        try:
            with open(self.gift_file_path, 'r', encoding='utf-8') as f:
                gifts_data = json.load(f)
            
            new_gifts = []
            current_gifts = set()
            
            if isinstance(gifts_data, list):
                for gift in gifts_data:
                    gift_id = str(gift.get('gift_id', gift.get('id', '')))
                    if gift_id:
                        current_gifts.add(gift_id)
                        if gift_id not in self.known_gifts:
                            new_gifts.append(gift)
            elif isinstance(gifts_data, dict):
                for gift_id, gift_data in gifts_data.items():
                    gift_id = str(gift_id)
                    current_gifts.add(gift_id)
                    if gift_id not in self.known_gifts:
                        new_gifts.append(gift_data)
            
            self.known_gifts = current_gifts
            
            if new_gifts:
                logger.info(f"🔥 Detected {len(new_gifts)} new gifts - notifying AutoBuy system")
                for callback in self.listeners:
                    try:
                        await callback(new_gifts)
                    except Exception as e:
                        logger.error(f"Error calling gift sync listener: {e}")
                        
        except Exception as e:
            logger.error(f"Error processing file changes: {e}")

gift_sync_manager = GiftSyncManager()

async def get_gift_sync_manager():
    return gift_sync_manager