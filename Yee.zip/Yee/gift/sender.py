
import logging
from typing import Dict, Any, Optional
from aiogram import Bot
from aiogram.exceptions import TelegramAPIError

logger = logging.getLogger(__name__)

class GiftSender:
    def __init__(self, bot: Bot):
        self.bot = bot
    
    async def send_gift_to_user(self, user_id: int, gift_id: str) -> bool:
        try:
            result = await self.bot.send_gift(
                gift_id=gift_id,
                user_id=user_id
            )
            
            logger.info(f"✓ Successfully sent gift {gift_id} to user {user_id}")
            return True
            
        except TelegramAPIError as e:
            error_msg = str(e)
            
            if "GIFT_NOT_FOUND" in error_msg:
                logger.error(f"Gift {gift_id} not found")
            elif "GIFT_SOLD_OUT" in error_msg:
                logger.error(f"Gift {gift_id} is sold out")
            elif "BALANCE_TOO_LOW" in error_msg or "INSUFFICIENT_FUNDS" in error_msg:
                logger.error(f"Insufficient stars to send gift {gift_id}")
            elif "USER_NOT_FOUND" in error_msg:
                logger.error(f"User {user_id} not found")
            elif "Bad Request" in error_msg:
                logger.error(f"Invalid gift ID or parameters: {gift_id}")
            else:
                logger.error(f"Failed to send gift {gift_id} to user {user_id}: {error_msg}")
            
            return False
            
        except Exception as e:
            logger.error(f"Unexpected error sending gift {gift_id} to user {user_id}: {e}")
            return False
    
    async def send_multiple_gifts(self, user_id: int, gift_id: str, quantity: int = 1) -> int:
        success_count = 0
        
        for i in range(quantity):
            try:
                success = await self.send_gift_to_user(user_id, gift_id)
                if success:
                    success_count += 1
                    logger.info(f"Sent gift {i+1}/{quantity} to user {user_id}")
                else:
                    logger.warning(f"Failed to send gift {i+1}/{quantity} to user {user_id}")
                    break
                    
            except Exception as e:
                logger.error(f"Error sending gift {i+1}/{quantity}: {e}")
                break
        
        return success_count

class GiftFilter:
    
    @staticmethod
    def check_gift_eligibility(gift_data: Dict[str, Any], user_settings: Dict[str, Any]) -> tuple[bool, str]:
        gift_price = gift_data.get("stars", 0)
        is_limited = gift_data.get("is_limited", False)
        is_sold_out = gift_data.get("sold_out", False)
        available_amount = gift_data.get("available_amount", 0)
        
        if is_sold_out:
            return False, "Gift is sold out"
        
        if is_limited and available_amount is not None and available_amount <= 0:
            return False, "Limited gift not available"
        
        if user_settings.get('filter_enabled', False) and not is_limited:
            return False, "User only wants limited gifts"
        
        max_price = user_settings.get('max_price_limit', float('inf'))
        min_price = user_settings.get('min_price_limit', 0)
        
        if gift_price > max_price:
            return False, f"Gift price {gift_price} exceeds max price {max_price}"
        
        if gift_price < min_price:
            return False, f"Gift price {gift_price} below min price {min_price}"
        
        user_balance = user_settings.get('stars_balance', 0)
        if gift_price > user_balance:
            return False, f"Insufficient balance: need {gift_price}, have {user_balance}"
        
        return True, "Gift is eligible"

gift_sender = None

def get_gift_sender(bot: Bot) -> GiftSender:
    global gift_sender
    if gift_sender is None:
        gift_sender = GiftSender(bot)
    return gift_sender