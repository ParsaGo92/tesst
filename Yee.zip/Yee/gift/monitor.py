
import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, Any, Set
from gift.sender import get_gift_sender, GiftFilter
from database.user_manager import user_data_manager

logger = logging.getLogger(__name__)

class GiftMonitor:
    def __init__(self, bot, gifts_file: str = "data/gifts.json", check_interval: int = 10):
        self.bot = bot
        self.gifts_file = Path(gifts_file)
        self.check_interval = check_interval
        self.gift_sender = get_gift_sender(bot)
        self.processed_gifts: Set[str] = set()
        self.running = False
        self.task = None
        
    async def start(self):
        if not self.running:
            self.running = True

            await self._load_existing_gifts()
            self.task = asyncio.create_task(self._monitor_loop())
            logger.info("Gift monitor started")
    
    async def stop(self):
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            logger.info("Gift monitor stopped")
    
    async def _load_existing_gifts(self):
        try:
            if self.gifts_file.exists():
                with open(self.gifts_file, 'r', encoding='utf-8') as f:
                    gifts_data = json.load(f)
                    

                if isinstance(gifts_data, list):
                    for gift in gifts_data:
                        gift_id = str(gift.get('gift_id', gift.get('id', '')))
                        if gift_id:
                            self.processed_gifts.add(gift_id)
                elif isinstance(gifts_data, dict):
                    for gift_id, gift_data in gifts_data.items():
                        self.processed_gifts.add(str(gift_id))
                        
                logger.info(f"Loaded {len(self.processed_gifts)} existing gifts")
        except Exception as e:
            logger.error(f"Error loading existing gifts: {e}")
    
    async def _monitor_loop(self):
        while self.running:
            try:
                await self._check_for_new_gifts()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in gift monitor loop: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _check_for_new_gifts(self):
        try:
            if not self.gifts_file.exists():
                return
                
            with open(self.gifts_file, 'r', encoding='utf-8') as f:
                gifts_data = json.load(f)
            
            new_gifts = []
            

            if isinstance(gifts_data, list):
                for gift in gifts_data:
                    gift_id = str(gift.get('gift_id', gift.get('id', '')))
                    if gift_id and gift_id not in self.processed_gifts:
                        new_gifts.append(gift)
                        self.processed_gifts.add(gift_id)
            elif isinstance(gifts_data, dict):
                for gift_id, gift_data in gifts_data.items():
                    if str(gift_id) not in self.processed_gifts:

                        if not isinstance(gift_data, dict):
                            continue
                        gift_data['gift_id'] = gift_id
                        new_gifts.append(gift_data)
                        self.processed_gifts.add(str(gift_id))
            
            if new_gifts:
                logger.info(f"Found {len(new_gifts)} new gifts")
                await self._process_new_gifts(new_gifts)
                
        except Exception as e:
            logger.error(f"Error checking for new gifts: {e}")
    
    async def _process_new_gifts(self, new_gifts: list):
        autobuy_users = await user_data_manager.get_all_autobuy_users()
        
        if not autobuy_users:
            logger.info("No autobuy users found")
            return
        
        for gift in new_gifts:
            gift_id = str(gift.get('gift_id', gift.get('id', 'Unknown')))
            gift_price = gift.get('stars', 0)
            is_limited = gift.get('is_limited', False)
            available_amount = gift.get('available_amount', 0)
            
            logger.info(f"Processing new gift {gift_id}: {gift_price} stars, limited: {is_limited}")
            

            if gift.get('sold_out', False):
                logger.info(f"Gift {gift_id} is sold out, skipping")
                continue
                
            if is_limited and available_amount <= 0:
                logger.info(f"Limited gift {gift_id} has no availability, skipping")
                continue
            

            for user_data in autobuy_users:
                try:
                    await self._process_gift_for_user(gift, user_data)
                except Exception as e:
                    logger.error(f"Error processing gift {gift_id} for user {user_data['user_id']}: {e}")
    
    async def _process_gift_for_user(self, gift: Dict[str, Any], user_data: Dict[str, Any]):
        user_id = user_data['user_id']
        gift_id = str(gift.get('gift_id', gift.get('id', 'Unknown')))
        

        is_eligible, reason = GiftFilter.check_gift_eligibility(gift, user_data)
        
        if not is_eligible:
            logger.debug(f"Gift {gift_id} not eligible for user {user_id}: {reason}")
            return
        
        try:
            success = await self.gift_sender.send_gift_to_user(
                user_id=user_id,
                gift_id=gift_id
            )
            
            if success:
                gift_cost = gift.get('stars', 0)
                balance_success = await user_data_manager.spend_stars(user_id, gift_cost)
                
                if balance_success:
                    logger.info(f"✓ Successfully sent gift {gift_id} to user {user_id} for {gift_cost} stars")
                    
                    await self._send_purchase_notification(user_id, gift)
                else:
                    logger.error(f"Gift sent but failed to deduct balance for user {user_id}")
            else:
                logger.warning(f"Failed to send gift {gift_id} to user {user_id}")
                
        except Exception as e:
            logger.error(f"Error sending gift {gift_id} to user {user_id}: {e}")
    
    async def _send_purchase_notification(self, user_id: int, gift: Dict[str, Any]):
        try:
            gift_id = gift.get('gift_id', gift.get('id', 'Unknown'))
            stars = gift.get('stars', 0)
            is_limited = gift.get('is_limited', False)
            
            gift_type = "Limited" if is_limited else "Unlimited"
            message = f"🎁 Gift purchased automatically!\n\n"
            message += f"Type: {gift_type}\n"
            message += f"Gift ID: {gift_id}\n"
            message += f"Cost: {stars} stars"
            
            if is_limited:
                available = gift.get('available_amount', 0)
                total = gift.get('total_amount', 0)
                message += f"\nAvailability: {available}/{total}"
            
            await self.bot.send_message(user_id, message)
            
        except Exception as e:
            logger.error(f"Failed to send notification to user {user_id}: {e}")

gift_monitor = None

def get_gift_monitor(bot) -> GiftMonitor:
    global gift_monitor
    if gift_monitor is None:
        gift_monitor = GiftMonitor(bot)
    return gift_monitor