
import logging
import math
from typing import Dict, Any, List, Optional
from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext

from gift.loader import gift_loader
from database.user_manager import user_data_manager
from gift.sender import get_gift_sender, GiftFilter
from bot.keyboards import get_main_keyboard

logger = logging.getLogger(__name__)
browser_router = Router()

GIFTS_PER_PAGE = 3

class GiftBrowser:
    @staticmethod
    def create_pagination_keyboard(gifts: List[Dict], page: int, total_pages: int, user_id: int) -> InlineKeyboardMarkup:
        keyboard = []
        start_idx = page * GIFTS_PER_PAGE
        end_idx = min(start_idx + GIFTS_PER_PAGE, len(gifts))
        
        for i in range(start_idx, end_idx):
            gift = gifts[i]
            gift_id = str(gift.get('gift_id', gift.get('id', 'Unknown')))
            stars = gift.get('stars', 0)
            short_id = gift_id[-4:] if len(gift_id) > 4 else gift_id
            
            button_text = f"Gift {short_id} - {stars}"
            callback_data = f"view_gift:{gift_id}:{page}"
            
            keyboard.append([InlineKeyboardButton(
                text=button_text,
                callback_data=callback_data
            )])
        
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(
                text="◀️ Prev",
                callback_data=f"gifts_page:{page-1}"
            ))
        
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton(
                text="Next ▶️",
                callback_data=f"gifts_page:{page+1}"
            ))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton(
            text="⬅️ Back to Menu",
            callback_data="back_to_menu"
        )])
        
        return InlineKeyboardMarkup(inline_keyboard=keyboard)
    
    @staticmethod
    def create_gift_detail_keyboard(gift_id: str, page: int) -> InlineKeyboardMarkup:

        return InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text="✅ Confirm Purchase",
                callback_data=f"confirm_purchase:{gift_id}"
            )],
            [InlineKeyboardButton(
                text="⬅️ Back to List",
                callback_data=f"gifts_page:{page}"
            )]
        ])
    
    @staticmethod
    async def get_filtered_gifts(user_id: int) -> List[Dict[str, Any]]:
        try:
            user_data = await user_data_manager.get_user_data(user_id)
            gifts = await gift_loader.load_gifts()
            
            filtered_gifts = await gift_loader.filter_available_gifts(
                gifts=gifts,
                filter_limited_only=user_data['filter_enabled'],
                max_price=user_data['max_price_limit'],
                min_price=user_data['min_price_limit']
            )
            
            available_gifts = []
            for gift in filtered_gifts:
                is_eligible, reason = GiftFilter.check_gift_eligibility(gift, user_data)
                if is_eligible:
                    available_gifts.append(gift)
            
            return available_gifts
            
        except Exception as e:
            logger.error(f"Error getting filtered gifts: {e}")
            return []

@browser_router.callback_query(F.data == "view_available_gifts")
async def show_gift_browser(callback: CallbackQuery):

    user_id = callback.from_user.id
    
    try:
        gifts = await GiftBrowser.get_filtered_gifts(user_id)
        user_data = await user_data_manager.get_user_data(user_id)
        
        if not gifts:
            filter_status = "On" if user_data['filter_enabled'] else "Off"
            message = (
                f"No available gifts found\n\n"
                f"Current settings:\n"
                f"Balance: {user_data['stars_balance']} stars\n"
                f"Max price: {user_data['max_price_limit']} stars\n"
                f"Limited filter: {filter_status}"
            )
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="Settings", callback_data="filter_settings")],
                [InlineKeyboardButton(text="Back", callback_data="back_to_menu")]
            ])
            
            await callback.message.edit_text(message, reply_markup=keyboard)
            await callback.answer()
            return
        
        total_pages = math.ceil(len(gifts) / GIFTS_PER_PAGE)
        page = 0
        
        filter_status = "On" if user_data['filter_enabled'] else "Off"
        message = (
            f"Available Gifts ({len(gifts)} found)\n"
            f"Page {page + 1} of {total_pages}\n\n"
            f"Your settings:\n"
            f"• Filter limited gifts: {filter_status}\n"
            f"• Max price: {user_data['max_price_limit']} stars\n"
            f"• Your balance: {user_data['stars_balance']} stars"
        )
        
        keyboard = GiftBrowser.create_pagination_keyboard(gifts, page, total_pages, user_id)
        
        await callback.message.edit_text(message, reply_markup=keyboard)
        
    except Exception as e:
        logger.error(f"Error showing gift browser: {e}")
        await callback.message.edit_text(
            f"Error loading gifts: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await callback.answer()

@browser_router.callback_query(F.data.startswith("gifts_page:"))
async def handle_gift_pagination(callback: CallbackQuery):

    user_id = callback.from_user.id
    page = int(callback.data.split(":")[1])
    
    try:
        gifts = await GiftBrowser.get_filtered_gifts(user_id)
        user_data = await user_data_manager.get_user_data(user_id)
        
        if not gifts:
            await show_gift_browser(callback)
            return
        
        total_pages = math.ceil(len(gifts) / GIFTS_PER_PAGE)
        
        page = max(0, min(page, total_pages - 1))
        
        filter_status = "On" if user_data['filter_enabled'] else "Off"
        message = (
            f"Available Gifts ({len(gifts)} found)\n"
            f"Page {page + 1} of {total_pages}\n\n"
            f"Your settings:\n"
            f"• Filter limited gifts: {filter_status}\n"
            f"• Max price: {user_data['max_price_limit']} stars\n"
            f"• Your balance: {user_data['stars_balance']} stars"
        )
        
        keyboard = GiftBrowser.create_pagination_keyboard(gifts, page, total_pages, user_id)
        
        await callback.message.edit_text(message, reply_markup=keyboard)
        
    except Exception as e:
        logger.error(f"Error handling pagination: {e}")
        await callback.message.edit_text(
            f"Error: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await callback.answer()

@browser_router.callback_query(F.data.startswith("view_gift:"))
async def show_gift_detail(callback: CallbackQuery):

    try:
        parts = callback.data.split(":")
        gift_id = parts[1]
        page = int(parts[2])
        
        user_id = callback.from_user.id
        user_data = await user_data_manager.get_user_data(user_id)
        
        gifts = await gift_loader.load_gifts()
        target_gift = None
        
        for gift in gifts:
            if str(gift.get('gift_id', gift.get('id', ''))) == gift_id:
                target_gift = gift
                break
        
        if not target_gift:
            await callback.message.edit_text(
                "Gift is no longer available.",
                reply_markup=GiftBrowser.create_pagination_keyboard(
                    await GiftBrowser.get_filtered_gifts(user_id), 
                    page, 
                    1, 
                    user_id
                )
            )
            await callback.answer()
            return
        
        if target_gift.get('sold_out', False):
            await callback.message.edit_text(
                "❌ Gift is no longer available.",
                reply_markup=GiftBrowser.create_pagination_keyboard(
                    await GiftBrowser.get_filtered_gifts(user_id), 
                    page, 
                    1, 
                    user_id
                )
            )
            await callback.answer()
            return
        
        is_limited = target_gift.get('is_limited', False)
        available_amount = target_gift.get('available_amount', 0)
        
        if is_limited and available_amount <= 0:
            await callback.message.edit_text(
                "❌ Gift is no longer available.",
                reply_markup=GiftBrowser.create_pagination_keyboard(
                    await GiftBrowser.get_filtered_gifts(user_id), 
                    page, 
                    1, 
                    user_id
                )
            )
            await callback.answer()
            return
        
        stars = target_gift.get('stars', 0)
        short_id = gift_id[-4:] if len(gift_id) > 4 else gift_id
        
        message = f"Gift #{short_id}\n"
        message += f"Price: {stars} Stars\n"
        
        if is_limited:
            message += f"Available: {available_amount}\n"
        else:
            message += "Available: Unlimited\n"
        
        message += f"\nYour balance: {user_data['stars_balance']} stars\n\n"
        message += "Do you want to buy this gift?"
        
        keyboard = GiftBrowser.create_gift_detail_keyboard(gift_id, page)
        
        await callback.message.edit_text(message, reply_markup=keyboard)
        
    except Exception as e:
        logger.error(f"Error showing gift detail: {e}")
        await callback.message.edit_text(
            f"Error: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await callback.answer()

@browser_router.callback_query(F.data.startswith("confirm_purchase:"))
async def confirm_gift_purchase(callback: CallbackQuery):

    try:
        gift_id = callback.data.split(":")[1]
        user_id = callback.from_user.id
        
        user_data = await user_data_manager.get_user_data(user_id)
        
        gifts = await gift_loader.load_gifts()
        target_gift = None
        
        for gift in gifts:
            if str(gift.get('gift_id', gift.get('id', ''))) == gift_id:
                target_gift = gift
                break
        
        if not target_gift:
            await callback.message.edit_text(
                "❌ Gift is no longer available.",
                reply_markup=get_main_keyboard()
            )
            await callback.answer()
            return
        
        is_eligible, reason = GiftFilter.check_gift_eligibility(target_gift, user_data)
        
        if not is_eligible:
            await callback.message.edit_text(
                f"⚠️ {reason}",
                reply_markup=get_main_keyboard()
            )
            await callback.answer()
            return
        
        gift_cost = target_gift.get('stars', 0)
        if user_data['stars_balance'] < gift_cost:
            await callback.message.edit_text(
                "⚠️ You don't have enough stars.",
                reply_markup=get_main_keyboard()
            )
            await callback.answer()
            return
        
        gift_sender = get_gift_sender(callback.bot)
        success = await gift_sender.send_gift_to_user(
            user_id=user_id,
            gift_id=gift_id
        )
        
        if success:
            balance_success = await user_data_manager.spend_stars(user_id, gift_cost)
            
            if balance_success:
                new_balance = (await user_data_manager.get_user_data(user_id))['stars_balance']
                short_id = gift_id[-4:] if len(gift_id) > 4 else gift_id
                
                await callback.message.edit_text(
                    f"✅ Gift purchased successfully.\n\n"
                    f"Gift #{short_id}\n"
                    f"Cost: {gift_cost} stars\n"
                    f"New balance: {new_balance} stars\n\n"
                    f"Check your Telegram gifts!",
                    reply_markup=get_main_keyboard()
                )
            else:
                await callback.message.edit_text(
                    "⚠️ Gift sent but balance update failed.",
                    reply_markup=get_main_keyboard()
                )
        else:
            await callback.message.edit_text(
                "❌ Purchase failed. Gift may no longer be available.",
                reply_markup=get_main_keyboard()
            )
        
    except Exception as e:
        logger.error(f"Error confirming purchase: {e}")
        await callback.message.edit_text(
            f"❌ Purchase error: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await callback.answer()

@browser_router.callback_query(F.data == "toggle_gift_filter")
async def toggle_gift_filter(callback: CallbackQuery):
    user_id = callback.from_user.id
    
    try:
        new_state = await user_data_manager.toggle_filter(user_id)
        status = "ON" if new_state else "OFF"
        
        # Return to gift browser with updated filter
        await show_gift_browser(callback)
        
    except Exception as e:
        logger.error(f"Error toggling filter: {e}")
        await callback.answer(f"Error: {str(e)}")

@browser_router.callback_query(F.data == "back_to_menu")
async def handle_back_to_menu_browser(callback: CallbackQuery):
    user_id = callback.from_user.id
    user_data = await user_data_manager.get_user_data(user_id)
    
    from bot.markdown_formatter import format_main_menu
    from bot.keyboards import get_main_keyboard
    
    autobuy_status = "On" if user_data['autobuy_enabled'] else "Off"
    filter_status = "On" if user_data['filter_enabled'] else "Off"
    
    message_text = format_main_menu(
        user_data['stars_balance'],
        autobuy_status,
        filter_status
    )
    
    await callback.message.edit_text(
        message_text,
        reply_markup=get_main_keyboard(),
        parse_mode="MarkdownV2"
    )
    await callback.answer()