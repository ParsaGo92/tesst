
import json
import os
from typing import Dict, Set, Any
from datetime import datetime

class CleanGiftManager:
    
    def __init__(self, filename: str = "data/gifts.json"):
        self.filename = filename
        self.known_gift_ids: Set[str] = set()
        self.gifts_data: Dict[str, Dict[str, Any]] = {}
        self.load_existing_gifts()
    
    def load_existing_gifts(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        for gift in data:
                            gift_id = gift.get('gift_id')
                            if gift_id:
                                self.known_gift_ids.add(gift_id)
                                self.gifts_data[gift_id] = gift
                    elif isinstance(data, dict):
                        for gift_id, gift_data in data.items():
                            self.known_gift_ids.add(gift_id)
                            self.gifts_data[gift_id] = gift_data
            except:
                self.known_gift_ids = set()
                self.gifts_data = {}
    
    def add_gift(self, gift_data: Dict[str, Any]) -> bool:
        gift_id = str(gift_data.get('id', ''))
        
        if gift_id in self.known_gift_ids:
            return False
        
        clean_gift = {
            'gift_id': gift_id,
            'stars': gift_data.get('stars', 0),
            'total_amount': gift_data.get('total_amount'),
            'available_amount': gift_data.get('available_amount'),
            'is_limited': gift_data.get('is_limited', False),
            'sold_out': gift_data.get('is_limited', False) and gift_data.get('available_amount', 0) == 0,
            'sell_percentage': self._calculate_sell_percentage(gift_data),
            'first_detected': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        self.known_gift_ids.add(gift_id)
        self.gifts_data[gift_id] = clean_gift
        self.save_all_gifts()
        return True
    
    def update_gift(self, gift_data: Dict[str, Any]) -> bool:
        gift_id = str(gift_data.get('id', ''))
        
        if gift_id not in self.known_gift_ids:
            return self.add_gift(gift_data)
        
        existing_gift = self.gifts_data[gift_id]
        current_available = gift_data.get('available_amount')
        old_available = existing_gift.get('available_amount')
        
        if current_available != old_available:
            existing_gift['available_amount'] = current_available
            existing_gift['sold_out'] = gift_data.get('is_limited', False) and current_available == 0
            existing_gift['sell_percentage'] = self._calculate_sell_percentage(gift_data)
            existing_gift['last_updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.save_all_gifts()
            return True
        
        return False
    
    def _calculate_sell_percentage(self, gift_data: Dict[str, Any]) -> float:
        if not gift_data.get('is_limited', False):
            return 0.0
        
        total = gift_data.get('total_amount', 0)
        available = gift_data.get('available_amount', 0)
        
        if total and total > 0:
            return round((1 - (available / total)) * 100, 1)
        return 0.0
    
    def save_all_gifts(self):
        try:
            sorted_gifts = sorted(
                self.gifts_data.values(), 
                key=lambda x: x.get('stars', 0), 
                reverse=True
            )
            
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(sorted_gifts, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Error saving gifts: {e}")
    
    def clear_and_rebuild(self, new_gifts: Dict[int, Dict[str, Any]]):
        self.known_gift_ids.clear()
        self.gifts_data.clear()
        
        for gift_id, gift_data in new_gifts.items():
            self.add_gift(gift_data)
        
        print(f"✅ Rebuilt clean gifts database with {len(self.gifts_data)} unique gifts")
    
    def get_stats(self) -> Dict[str, Any]:
        total_gifts = len(self.gifts_data)
        limited_gifts = sum(1 for g in self.gifts_data.values() if g.get('is_limited', False))
        unlimited_gifts = total_gifts - limited_gifts
        sold_out_gifts = sum(1 for g in self.gifts_data.values() if g.get('sold_out', False))
        
        return {
            'total_gifts': total_gifts,
            'limited_gifts': limited_gifts,
            'unlimited_gifts': unlimited_gifts,
            'sold_out_gifts': sold_out_gifts,
            'available_gifts': limited_gifts - sold_out_gifts
        }
    
    def get_high_value_gifts(self, min_stars: int = 1000) -> list:
        return [
            gift for gift in self.gifts_data.values() 
            if gift.get('stars', 0) >= min_stars
        ]