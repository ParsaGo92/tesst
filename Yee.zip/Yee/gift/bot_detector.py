import asyncio
import time
from typing import Set, Dict, Any, Optional
from aiogram import Bot
from config.settings import BOT_TOKEN
from utils.logger import setup_logger, log_gift_detection, log_error, log_status, log_summary
from utils.events import GiftEventEmitter, GiftEvents
from gift.data_manager import CleanGiftManager

gift_event_emitter = GiftEventEmitter()

class BotGiftDetector:
    def __init__(self):
        self.bot = Bot(token=BOT_TOKEN)
        self.logger = setup_logger(__name__)
        self.known_gifts: Set[int] = set()
        self.previous_gifts_state: Dict[int, Dict[str, Any]] = {}
        self.start_time = time.time()
        self.scan_count = 0
        self.total_new_gifts_found = 0
        self.initial_scan_done = False
        self.clean_manager = CleanGiftManager("data/gifts.json")
        
    async def get_all_gifts(self) -> Optional[Dict[int, Any]]:
        try:
            with open("data/gifts.json", "r") as f:
                import json
                gifts_data = json.load(f)
                
            gifts_dict = {}
            for gift in gifts_data:
                gift_id = int(gift.get('gift_id', 0))
                if gift_id > 0:
                    gifts_dict[gift_id] = {
                        'id': gift_id,
                        'gift_id': gift.get('gift_id'),
                        'stars': gift.get('stars', 0),
                        'total_amount': gift.get('total_amount'),
                        'available_amount': gift.get('available_amount'),
                        'is_limited': gift.get('is_limited', False),
                        'sold_out': gift.get('sold_out', False),
                        'first_detected': gift.get('first_detected'),
                        'last_updated': gift.get('last_updated')
                    }
            
            return gifts_dict
                
        except Exception as e:
            log_error(f"Error loading gifts from file: {e}")
            return None
    
    def save_new_gift_json(self, gift_data: Dict[str, Any]):
        was_added = self.clean_manager.add_gift(gift_data)
        if was_added:
            print(f"✅ New gift saved: {gift_data.get('id')} ({gift_data.get('stars')} stars)")
        return was_added
    
    async def emit_gift_event(self, gift_data: Dict[str, Any]):
        gift_id = gift_data.get('id')
        stars = gift_data.get('stars', 0)
        total = gift_data.get('total_amount')
        available = gift_data.get('available_amount')
        is_limited = gift_data.get('is_limited', False)
        
        log_gift_detection(
            gift_id=str(gift_id),
            gift_type="star_gift",
            star_count=stars,
            total_count=total,
            remaining_count=available
        )
    
    async def monitor_gifts(self):
        first_run = True
        
        while True:
            try:
                scan_start_time = time.time()
                gifts_dict = await self.get_all_gifts()
                scan_duration = time.time() - scan_start_time
                self.scan_count += 1
                
                if gifts_dict:
                    new_gifts = []
                    updated_gifts = []
                    
                    for gift_id, gift_data in gifts_dict.items():
                        if gift_id not in self.known_gifts:
                            new_gifts.append(gift_data)
                            self.known_gifts.add(gift_id)
                            await self.emit_gift_event(gift_data)
                        elif gift_id in self.previous_gifts_state:
                            old_data = self.previous_gifts_state[gift_id]
                            if (old_data.get('available_amount') != gift_data.get('available_amount') or
                                old_data.get('sold_out') != gift_data.get('sold_out')):
                                updated_gifts.append(gift_data)
                                await self.emit_gift_event(gift_data)
                    
                    self.previous_gifts_state = gifts_dict.copy()
                    
                    if new_gifts:
                        self.total_new_gifts_found += len(new_gifts)
                        await gift_event_emitter.emit(GiftEvents.NEW_GIFTS_FOUND, {
                            'new_gifts': new_gifts,
                            'total_new_this_session': self.total_new_gifts_found,
                            'scan_number': self.scan_count
                        })
                        
                        for gift in new_gifts:
                            self.save_new_gift_json(gift)
                
                    if first_run:
                        await gift_event_emitter.emit(GiftEvents.INITIAL_SCAN_COMPLETE, {
                            'total_gifts_found': len(gifts_dict) if gifts_dict else 0,
                            'scan_duration_seconds': round(scan_duration, 2),
                            'message': f'Initial scan complete - found {len(gifts_dict) if gifts_dict else 0} gifts'
                        })
                        first_run = False
                        self.initial_scan_done = True
                        log_status(f"Initial scan complete - found {len(gifts_dict) if gifts_dict else 0} gifts")
                        
                    uptime_minutes = int((time.time() - self.start_time) / 60)
                    
                    if new_gifts or updated_gifts:
                        log_status(f"Scan #{self.scan_count} - New: {len(new_gifts)}, Updated: {len(updated_gifts)} | Total: {len(gifts_dict)} | Uptime: {uptime_minutes}m")
                    else:
                        monitoring_data = {
                            'scan_number': self.scan_count,
                            'uptime_minutes': uptime_minutes,
                            'total_gifts': len(gifts_dict) if gifts_dict else 0,
                            'new_gifts_this_scan': 0,
                            'scan_duration_seconds': round(scan_duration, 2),
                            'total_new_this_session': self.total_new_gifts_found,
                            'status': 'monitoring_active'
                        }
                        
                        if gifts_dict:
                            current_limited = sum(1 for g in gifts_dict.values() if g.get('is_limited'))
                            current_sold_out = sum(1 for g in gifts_dict.values() if g.get('sold_out'))
                            current_total_stars = sum(g.get('stars', 0) for g in gifts_dict.values())
                            
                            monitoring_data.update({
                                'limited_gifts': current_limited,
                                'sold_out_gifts': current_sold_out,
                                'total_star_value': current_total_stars,
                                'estimated_usd_value': round(current_total_stars * 0.013, 2),
                                'availability_rate': round((1 - current_sold_out / max(current_limited, 1)) * 100, 1)
                            })
                        
                        await gift_event_emitter.emit(GiftEvents.MONITORING_STATUS, monitoring_data)
                        
                        if self.scan_count % 3 == 0:
                            log_status(f"File monitoring active - Scan #{self.scan_count} | Uptime: {uptime_minutes}m | Tracking: {len(gifts_dict)} gifts")
                        else:
                            log_status("No changes detected - monitoring continues...")
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                    'error_type': 'monitoring_error',
                    'error_message': str(e),
                    'recovery_action': 'retrying_in_10_seconds',
                    'scan_number': self.scan_count,
                    'uptime_minutes': int((time.time() - self.start_time) / 60)
                })
                log_error(f"Monitoring error: {e}")
                await asyncio.sleep(10)
    
    async def start(self):
        try:
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STARTED, {
                'status': 'starting',
                'message': 'Starting Bot-based gift detector...'
            })
            log_status("Starting Bot-based gift detector...")
            
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STARTED, {
                'status': 'connected',
                'message': 'Bot connected successfully!'
            })
            log_status("Bot connected successfully!")
            
            await self.monitor_gifts()
            
        except Exception as e:
            error_message = str(e)
            await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                'error_type': 'start_error',
                'error_message': error_message,
                'recovery_action': 'manual_restart_required'
            })
            log_error(f"Failed to start bot detector: {error_message}")
            raise
            
    async def stop(self):
        try:
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STOPPED, {
                'status': 'stopping',
                'message': 'Stopping gift detector...'
            })
            log_status("Stopping gift detector...")
            
            await self.bot.session.close()
            
        except Exception as e:
            log_error(f"Error stopping detector: {e}")