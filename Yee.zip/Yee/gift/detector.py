import asyncio
import time
from typing import Set, Dict, Any, Optional
from pyrogram import Client
from utils.parse_data import get_all_star_gifts
from config.telegram_config import CHECK_INTERVAL, API_ID, API_HASH
from utils.logger import setup_logger, log_gift_detection, log_error, log_status, log_summary
from utils.events import GiftEventEmitter, GiftEvents
from gift.data_manager import CleanGiftManager


gift_event_emitter = GiftEventEmitter()

try:
    from bot.telegram_client import set_shared_client
except ImportError:
    def set_shared_client(client):
        pass

class GiftDetector:
    def __init__(self):
        self.client = Client("gift_detector", API_ID, API_HASH, workdir="data/sessions/")
        self.logger = setup_logger(__name__)
        self.known_gifts: Set[int] = set()
        self.previous_gifts_state: Dict[int, Dict[str, Any]] = {}
        self.start_time = time.time()
        self.scan_count = 0
        self.total_new_gifts_found = 0
        self.initial_scan_done = False
        self.clean_manager = CleanGiftManager("data/gifts.json")
        
    async def get_all_gifts(self) -> Optional[Dict[int, Any]]:
        try:
            raw_gifts, gifts_dict = await get_all_star_gifts(self.client)
            
            if gifts_dict and len(gifts_dict) > 0:
                return gifts_dict
            else:
                return None
                
        except Exception as e:
            log_error(f"Error getting gifts: {e}")
            return None
    
    def save_new_gift_json(self, gift_data: Dict[str, Any]):
        was_added = self.clean_manager.add_gift(gift_data)
        if was_added:
            print(f"✅ New gift saved: {gift_data.get('id')} ({gift_data.get('stars')} stars)")
        return was_added
    
    async def emit_gift_event(self, gift_data: Dict[str, Any]):
        gift_id = gift_data.get('id')
        stars = gift_data.get('stars', 0)
        total = gift_data.get('total_amount')
        available = gift_data.get('available_amount')
        is_limited = gift_data.get('is_limited', False)
        
        gift_type = "limited_star_gift" if is_limited else "star_gift"
        
        self.save_new_gift_json(gift_data)
        
        log_gift_detection(
            gift_id=str(gift_id),
            gift_type=gift_type,
            star_count=stars,
            total_count=total,
            remaining_count=available
        )
    
    async def monitor_gifts(self):
        first_run = True
        
        while True:
            try:
                scan_start_time = time.time()
                gifts_dict = await self.get_all_gifts()
                scan_duration = time.time() - scan_start_time
                self.scan_count += 1
                
                if gifts_dict:
                    new_gifts = []
                    changed_gifts = []
                    
                    for gift_id, gift_data in gifts_dict.items():
                        if gift_id not in self.known_gifts:
                            new_gifts.append(gift_data)
                            self.known_gifts.add(gift_id)
                            if self.initial_scan_done:
                                self.total_new_gifts_found += 1
                        else:
                            if gift_id in self.previous_gifts_state:
                                old_state = self.previous_gifts_state[gift_id]
                                current_remaining = gift_data.get('available_amount', 0)
                                old_remaining = old_state.get('available_amount', 0)
                                
                                if current_remaining != old_remaining:
                                    change_data = {
                                        'gift_id': gift_id,
                                        'stars': gift_data.get('stars', 0),
                                        'old_remaining': old_remaining,
                                        'new_remaining': current_remaining,
                                        'change': current_remaining - old_remaining,
                                        'total_count': gift_data.get('total_amount')
                                    }
                                    changed_gifts.append(change_data)
                    
                    for gift_id, gift_data in gifts_dict.items():
                        self.previous_gifts_state[gift_id] = gift_data.copy()
                    
                    uptime_minutes = int((time.time() - self.start_time) / 60)
                    gifts_per_second = len(gifts_dict) / scan_duration if scan_duration > 0 else 0
                    
                    if first_run:
                        if new_gifts:
                            self.clean_manager.clear_and_rebuild(gifts_dict)
                            
                            limited_count = sum(1 for g in gifts_dict.values() if g.get('is_limited', False))
                            unlimited_count = len(gifts_dict) - limited_count
                            
                            total_stars = sum(g.get('stars', 0) for g in gifts_dict.values())
                            high_value_count = sum(1 for g in gifts_dict.values() if g.get('stars', 0) >= 1000)
                            sold_out_count = sum(1 for g in gifts_dict.values() 
                                               if g.get('is_limited', False) and g.get('available_amount', 0) == 0)
                            
                            log_status(f"Initial scan: Found {len(new_gifts)} gifts - Displaying all gifts:")
                            
                            sorted_gifts = sorted(
                                [gifts_dict[gift_data.get('id')] for gift_data in new_gifts if gift_data.get('id') in gifts_dict], 
                                key=lambda x: x.get('stars', 0), 
                                reverse=True
                            )
                            
                            for gift_data in sorted_gifts:
                                gift_id = gift_data.get('id')
                                stars = gift_data.get('stars', 0)
                                total = gift_data.get('total_amount')
                                available = gift_data.get('available_amount')
                                is_limited = gift_data.get('is_limited', False)
                                gift_type = "limited_star_gift" if is_limited else "star_gift"
                                
                                log_gift_detection(
                                    gift_id=str(gift_id),
                                    gift_type=gift_type,
                                    star_count=stars,
                                    total_count=total,
                                    remaining_count=available
                                )
                            
                            log_summary(len(gifts_dict), limited_count, unlimited_count)
                            
                            stats = self.clean_manager.get_stats()
                            print(f"📊 Clean Database Stats: {stats['total_gifts']} total, {stats['limited_gifts']} limited, {stats['sold_out_gifts']} sold out")
                        
                        log_status("🔍 Starting monitoring for new gifts...")
                        first_run = False
                        self.initial_scan_done = True  # Mark initial scan as completed
                        
                    elif new_gifts or changed_gifts:
                        if new_gifts:
                            for gift_data in new_gifts:
                                await self.emit_gift_event(gift_data)
                            
                            log_status(f"🆕 NEW GIFTS DETECTED: {len(new_gifts)} new gifts found!")
                        
                        if changed_gifts:
                            changes_data = {
                                'changed_gifts_count': len(changed_gifts),
                                'changes': changed_gifts,
                                'scan_number': self.scan_count
                            }
                            await gift_event_emitter.emit("gift_availability_changed", changes_data)
                    
                    else:
                        current_limited = sum(1 for g in gifts_dict.values() if g.get('is_limited', False))
                        current_sold_out = sum(1 for g in gifts_dict.values() 
                                             if g.get('is_limited', False) and g.get('available_amount', 0) == 0)
                        current_total_stars = sum(g.get('stars', 0) for g in gifts_dict.values())
                        
                        monitoring_data = {
                            'status': 'monitoring_active',
                            'message': 'No new gifts found - monitoring continues...',
                            'scan_number': self.scan_count,
                            'uptime_minutes': uptime_minutes,
                            'total_gifts_tracked': len(self.known_gifts),
                            'new_gifts_detected_since_start': self.total_new_gifts_found,
                            'scan_duration_seconds': round(scan_duration, 2),
                            'gifts_per_second': round(gifts_per_second, 1),
                            'marketplace_stats': {
                                'limited_gifts': current_limited,
                                'sold_out_gifts': current_sold_out,
                                'total_stars_value': current_total_stars,
                                'estimated_usd_value': round(current_total_stars * 0.013, 2),
                                'availability_rate': round((1 - current_sold_out / max(current_limited, 1)) * 100, 1)
                            }
                        }
                        await gift_event_emitter.emit(GiftEvents.MONITORING_STATUS, monitoring_data)
                        
                        if self.scan_count % 3 == 0:
                            log_status(f"Monitoring active - Scan #{self.scan_count} | Uptime: {uptime_minutes}m | Tracking: {len(self.known_gifts)} gifts")
                        else:
                            log_status("No new gifts found - monitoring continues...")
                
                await asyncio.sleep(CHECK_INTERVAL)
                
            except Exception as e:
                await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                    'error_type': 'monitoring_error',
                    'error_message': str(e),
                    'recovery_action': 'retrying_in_10_seconds',
                    'scan_number': self.scan_count,
                    'uptime_minutes': int((time.time() - self.start_time) / 60)
                })
                log_error(f"Monitoring error: {e}")
                await asyncio.sleep(10)
    
    async def start(self):
        try:
            # Emit detector starting event
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STARTED, {
                'status': 'starting',
                'message': 'Starting gift detector...'
            })
            log_status("Starting gift detector...")
            
            await self.client.start()
            
            # Share client with bot modules
            set_shared_client(self.client)
            

            
            # Emit connection success event
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STARTED, {
                'status': 'connected',
                'message': 'Connected successfully!'
            })
            log_status("Connected successfully!")
            
            await self.monitor_gifts()
        except Exception as e:
            error_message = str(e)
            
            # Handle specific authentication errors
            if "AUTH_KEY_DUPLICATED" in error_message:
                log_error("Session file corrupted (AUTH_KEY_DUPLICATED)")
                log_status("🔄 System will attempt recovery...")
                
                # Clean up corrupted session file
                import os
                session_file = "gift_detector.session"
                if os.path.exists(session_file):
                    os.remove(session_file)
                    log_status("✅ Corrupted session file removed")
                
                await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                    'error_type': 'auth_key_duplicated',
                    'error_message': 'Session file corrupted, automatic cleanup performed',
                    'recovery_action': 'session_cleaned_restart_required'
                })
                log_status("💡 Please restart the application to create a fresh session")
            else:
                # Emit start error event for other errors
                await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                    'error_type': 'start_error',
                    'error_message': error_message,
                    'recovery_action': 'manual_restart_required'
                })
                log_error(f"Failed to start: {e}")
                log_status("🔄 System will attempt recovery...")
    
    async def stop(self):
        try:
            await self.client.stop()
            
            # Emit detector stopped event
            await gift_event_emitter.emit(GiftEvents.DETECTOR_STOPPED, {
                'status': 'stopped',
                'message': 'Stopped successfully'
            })
            log_status("Stopped successfully")
        except Exception as e:
            # Emit stop error event
            await gift_event_emitter.emit(GiftEvents.ERROR_OCCURRED, {
                'error_type': 'stop_error',
                'error_message': str(e),
                'recovery_action': 'forced_termination'
            })
            log_error(f"Error stopping: {e}")