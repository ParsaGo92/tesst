
import json
import aiofiles
from typing import List, Dict, Any, Optional
from pathlib import Path

class GiftLoader:
    def __init__(self, gift_file_path: str = "data/gifts.json"):
        self.gift_file_path = gift_file_path
    
    async def load_gifts(self) -> List[Dict[str, Any]]:
        try:
            file_path = Path(self.gift_file_path)
            if not file_path.exists():
                return []
            
            async with aiofiles.open(self.gift_file_path, 'r') as f:
                content = await f.read()
                gifts = json.loads(content)
                
            if isinstance(gifts, dict):
                return list(gifts.values())
            elif isinstance(gifts, list):
                return gifts
            else:
                return []
                
        except Exception as e:
            print(f"Error loading gifts: {e}")
            return []
    
    async def filter_available_gifts(
        self, 
        gifts: List[Dict[str, Any]], 
        filter_limited_only: bool = False,
        max_price: Optional[int] = None,
        min_price: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        available_gifts = []
        unlimited_gifts_count = 0
        limited_gifts_count = 0
        
        for gift in gifts:
            if gift.get('is_limited', False):
                limited_gifts_count += 1
            else:
                unlimited_gifts_count += 1
            
            if gift.get('sold_out', False):
                continue
            
            if gift.get('is_limited', False):
                available_amount = gift.get('available_amount', 0)
                if available_amount is not None and available_amount <= 0:
                    continue
            
            
            if filter_limited_only and not gift.get('is_limited', False):
                continue
            
            gift_price = gift.get('stars', 0)
            if max_price is not None and gift_price > max_price:
                continue
            if min_price is not None and gift_price < min_price:
                continue
            
            available_gifts.append(gift)
        
        print(f"Debug: Total gifts: {len(gifts)}, Limited: {limited_gifts_count}, Unlimited: {unlimited_gifts_count}")
        print(f"Debug: Filter settings - Limited only: {filter_limited_only}, Max price: {max_price}")
        print(f"Debug: Available gifts after filtering: {len(available_gifts)}")
        
        available_gifts.sort(key=lambda x: x.get('stars', 0))
        return available_gifts
    
    async def get_buyable_gifts(
        self, 
        user_balance: int,
        filter_limited_only: bool = False,
        max_price: Optional[int] = None,
        min_price: Optional[int] = None,
        max_count: int = 1
    ) -> List[Dict[str, Any]]:

        gifts = await self.load_gifts()
        available_gifts = await self.filter_available_gifts(
            gifts, filter_limited_only, max_price, min_price
        )
        
        buyable_gifts = []
        total_cost = 0
        
        for gift in available_gifts:
            gift_cost = gift.get('stars', 0)
            if total_cost + gift_cost <= user_balance and len(buyable_gifts) < max_count:
                buyable_gifts.append(gift)
                total_cost += gift_cost
            else:
                break
        
        return buyable_gifts

gift_loader = GiftLoader()