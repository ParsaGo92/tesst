import logging
import sys
from datetime import datetime

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

def setup_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    return logger

def log_gift_detection(gift_id: str, gift_type: str, star_count: int, 
                      total_count: int = None, remaining_count: int = None):
    timestamp = datetime.now().strftime("%H:%M:%S")
    

    if star_count >= 10000:
        color = Colors.RED + Colors.BOLD
        priority = "🔥 ULTRA HIGH"
        rarity = "LEGENDARY"
    elif star_count >= 5000:
        color = Colors.PURPLE + Colors.BOLD
        priority = "💎 VERY HIGH"
        rarity = "EPIC"
    elif star_count >= 1000:
        color = Colors.BLUE + Colors.BOLD
        priority = "⭐ HIGH"
        rarity = "RARE"
    elif star_count >= 500:
        color = Colors.CYAN + Colors.BOLD
        priority = "✨ MEDIUM"
        rarity = "UNCOMMON"
    else:
        color = Colors.GREEN + Colors.BOLD
        priority = "🎁 STANDARD"
        rarity = "COMMON"
    

    value_per_star = 1
    if star_count >= 1000:
        estimated_usd = star_count * 0.013
        value_info = f" (~${estimated_usd:.2f})"
    else:
        value_info = ""
    

    type_icon = "🎯" if gift_type == "limited_star_gift" else "♾️"
    
    print(f"{color}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
    print(f"{color}{type_icon} GIFT #{gift_id} | {priority} VALUE{Colors.END}")
    print(f"   {Colors.YELLOW}⭐ {star_count:,} stars{value_info} | {Colors.WHITE}{rarity}{Colors.END}")
    
    if total_count is not None and remaining_count is not None:

        availability_pct = (remaining_count / total_count * 100) if total_count > 0 else 0
        
        if remaining_count > 0:
            if availability_pct > 50:
                status_color = Colors.GREEN
                urgency = "GOOD STOCK"
            elif availability_pct > 20:
                status_color = Colors.YELLOW
                urgency = "MEDIUM STOCK"
            else:
                status_color = Colors.RED
                urgency = "LOW STOCK"
            
            status = f"✅ {remaining_count:,}/{total_count:,} available ({availability_pct:.1f}% | {urgency})"
        else:
            status_color = Colors.RED
            status = f"❌ COMPLETELY SOLD OUT | {total_count:,} total were available"
        
        print(f"   {status_color}{status}{Colors.END}")
        

        sold_count = total_count - remaining_count
        if sold_count > 0:
            demand_pct = (sold_count / total_count * 100)
            if demand_pct > 90:
                demand_indicator = f"{Colors.RED}🔥 EXTREME DEMAND ({demand_pct:.1f}% sold){Colors.END}"
            elif demand_pct > 70:
                demand_indicator = f"{Colors.YELLOW}📈 HIGH DEMAND ({demand_pct:.1f}% sold){Colors.END}"
            elif demand_pct > 30:
                demand_indicator = f"{Colors.CYAN}📊 MODERATE DEMAND ({demand_pct:.1f}% sold){Colors.END}"
            else:
                demand_indicator = f"{Colors.GREEN}📉 LOW DEMAND ({demand_pct:.1f}% sold){Colors.END}"
            print(f"   {demand_indicator}")
    else:
        print(f"   {Colors.CYAN}♾️  UNLIMITED AVAILABILITY{Colors.END}")
    
    print(f"   {Colors.WHITE}🕐 Detected at {timestamp} | Type: {gift_type.replace('_', ' ').title()}{Colors.END}")
    print(f"{color}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.END}")
    print()

def log_error(error_msg: str, error_type: str = "ERROR"):
    timestamp = datetime.now().strftime("%H:%M:%S")
    

    if "connection" in error_msg.lower() or "network" in error_msg.lower():
        icon = "🌐"
        category = "NETWORK ERROR"
        color = Colors.RED + Colors.BOLD
    elif "api" in error_msg.lower() or "telegram" in error_msg.lower():
        icon = "📡"
        category = "API ERROR"
        color = Colors.YELLOW + Colors.BOLD
    elif "timeout" in error_msg.lower():
        icon = "⏰"
        category = "TIMEOUT ERROR"
        color = Colors.PURPLE + Colors.BOLD
    elif "parsing" in error_msg.lower() or "json" in error_msg.lower():
        icon = "🔧"
        category = "DATA ERROR"
        color = Colors.CYAN + Colors.BOLD
    else:
        icon = "❌"
        category = error_type.upper()
        color = Colors.RED + Colors.BOLD
    
    print(f"{color}{icon} [{timestamp}] {category}{Colors.END}")
    print(f"   {Colors.WHITE}Details: {error_msg}{Colors.END}")
    print(f"   {Colors.YELLOW}🔄 System will attempt recovery...{Colors.END}")
    print()

def log_new_gift_alert(count: int):
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    if count == 1:
        alert_level = f"{Colors.GREEN}🎁 SINGLE NEW GIFT{Colors.END}"
    elif count <= 5:
        alert_level = f"{Colors.YELLOW}🎯 MULTIPLE GIFTS ({count}){Colors.END}"
    elif count <= 10:
        alert_level = f"{Colors.PURPLE}🚀 GIFT BURST ({count}){Colors.END}"
    else:
        alert_level = f"{Colors.RED}💥 GIFT FLOOD ({count}){Colors.END}"
    
    print(f"\n{Colors.BOLD}{Colors.YELLOW}{'🆕 ' * 20}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.YELLOW}NEW GIFT DETECTION | {timestamp}{Colors.END}")
    print(f"   {alert_level}")
    print(f"{Colors.BOLD}{Colors.YELLOW}{'🆕 ' * 20}{Colors.END}")

def log_performance_metrics(scan_time: float, gifts_per_second: float):
    """Log performance metrics for monitoring"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    if scan_time < 1.0:
        speed_rating = f"{Colors.GREEN}⚡ FAST{Colors.END}"
    elif scan_time < 3.0:
        speed_rating = f"{Colors.YELLOW}🔄 NORMAL{Colors.END}"
    else:
        speed_rating = f"{Colors.RED}🐌 SLOW{Colors.END}"
    
    print(f"{Colors.CYAN}📊 [{timestamp}] Performance: {scan_time:.2f}s | {gifts_per_second:.1f} gifts/sec | {speed_rating}{Colors.END}")

def log_system_stats(known_gifts_count: int, uptime_minutes: int):
    """Log system statistics"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    uptime_hours = uptime_minutes // 60
    uptime_mins = uptime_minutes % 60
    
    if uptime_hours > 0:
        uptime_str = f"{uptime_hours}h {uptime_mins}m"
    else:
        uptime_str = f"{uptime_mins}m"
    
    print(f"{Colors.WHITE}📈 [{timestamp}] System Stats: {known_gifts_count:,} tracked gifts | Uptime: {uptime_str}{Colors.END}")

def log_status(message: str):
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    # Enhanced status messages with more context
    if "Starting" in message:
        icon = "🚀"
        color = Colors.GREEN + Colors.BOLD
    elif "Connected" in message:
        icon = "✅"
        color = Colors.GREEN
    elif "monitoring" in message.lower():
        icon = "🔍"
        color = Colors.CYAN
    elif "NEW GIFTS" in message:
        icon = "🆕"
        color = Colors.YELLOW + Colors.BOLD
    elif "No new gifts" in message:
        icon = "⏳"
        color = Colors.WHITE
    else:
        icon = "ℹ️"
        color = Colors.CYAN
    
    print(f"{color}{icon} [{timestamp}] {message}{Colors.END}")

def log_summary(total_gifts: int, limited_gifts: int, unlimited_gifts: int):
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    # Calculate percentages
    limited_pct = (limited_gifts / total_gifts * 100) if total_gifts > 0 else 0
    unlimited_pct = (unlimited_gifts / total_gifts * 100) if total_gifts > 0 else 0
    
    # Determine market analysis
    if limited_pct > 80:
        market_trend = f"{Colors.RED}🔥 HIGH SCARCITY MARKET{Colors.END}"
    elif limited_pct > 60:
        market_trend = f"{Colors.YELLOW}📈 MODERATE SCARCITY{Colors.END}"
    else:
        market_trend = f"{Colors.GREEN}📊 BALANCED MARKET{Colors.END}"
    
    print(f"\n{Colors.BOLD}{Colors.GREEN}{'═'*80}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}🎯 INITIAL SCAN COMPLETE | {timestamp}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}{'═'*80}{Colors.END}")
    print(f"{Colors.YELLOW}📊 TOTAL GIFTS DISCOVERED: {total_gifts:,}{Colors.END}")
    print(f"{Colors.RED}🎯 Limited Edition Gifts: {limited_gifts:,} ({limited_pct:.1f}%){Colors.END}")
    print(f"{Colors.CYAN}♾️  Unlimited Gifts: {unlimited_gifts:,} ({unlimited_pct:.1f}%){Colors.END}")
    print(f"   {market_trend}")
    
    # Add discovery rate info
    if total_gifts > 100:
        discovery_rate = "🌟 EXCELLENT DISCOVERY"
    elif total_gifts > 50:
        discovery_rate = "✨ GOOD DISCOVERY"
    else:
        discovery_rate = "📍 STANDARD DISCOVERY"
    
    print(f"   {Colors.WHITE}{discovery_rate} | Market Status: Active{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}{'═'*80}{Colors.END}")
    print()

def log_new_gift_alert(count: int):
    print(f"\n{Colors.BOLD}{Colors.YELLOW}{'🆕 NEW GIFT ALERT ' + '='*44}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.YELLOW}Found {count} new gift{'s' if count > 1 else ''}!{Colors.END}")
    print(f"{Colors.BOLD}{Colors.YELLOW}{'='*60}{Colors.END}\n")