import asyncio
from typing import Dict, List, Callable, Any
from datetime import datetime
import json


class EventData:
    def __init__(self, event_type: str, data: Dict[str, Any], timestamp: str = None):
        self.event_type = event_type
        self.data = data
        self.timestamp = timestamp or datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'event_type': self.event_type,
            'data': self.data,
            'timestamp': self.timestamp
        }
    
    def to_json(self) -> str:
        clean_data = {
            'event_type': self.event_type,
            'timestamp': self.timestamp,
            'data': {}
        }
        

        for key, value in self.data.items():
            if key == 'raw_data':
                continue
            try:
                json.dumps(value)
                clean_data['data'][key] = value
            except (TypeError, ValueError):
                clean_data['data'][key] = str(value)
        
        return json.dumps(clean_data, ensure_ascii=False, indent=2, default=str)


class GiftEventEmitter:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}
        self._event_history: List[EventData] = []
        self._max_history = 1000
    
    def on(self, event_type: str, callback: Callable[[EventData], Any]):

        if event_type not in self._listeners:
            self._listeners[event_type] = []
        self._listeners[event_type].append(callback)
    
    def off(self, event_type: str, callback: Callable[[EventData], Any]):

        if event_type in self._listeners:
            try:
                self._listeners[event_type].remove(callback)
            except ValueError:
                pass
    
    async def emit(self, event_type: str, data: Dict[str, Any]) -> List[Any]:

        event_data = EventData(event_type, data)
        

        self._event_history.append(event_data)
        if len(self._event_history) > self._max_history:
            self._event_history.pop(0)
        

        results = []
        if event_type in self._listeners:
            for callback in self._listeners[event_type]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        result = await callback(event_data)
                    else:
                        result = callback(event_data)
                    results.append(result)
                except Exception as e:
                    print(f"Error in event listener: {e}")
        
        return results
    
    def get_event_history(self, event_type: str = None, limit: int = None) -> List[EventData]:
        """Get event history, optionally filtered by type"""
        events = self._event_history
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        if limit:
            events = events[-limit:]
        
        return events
    
    def clear_history(self):
        """Clear event history"""
        self._event_history.clear()


# Global event emitter instance
gift_event_emitter = GiftEventEmitter()


# Event type constants
class GiftEvents:
    """Constants for gift event types"""
    GIFT_DETECTED = "gift_detected"
    NEW_GIFTS_FOUND = "new_gifts_found"
    INITIAL_SCAN_COMPLETE = "initial_scan_complete"
    MONITORING_STATUS = "monitoring_status"
    ERROR_OCCURRED = "error_occurred"
    DETECTOR_STARTED = "detector_started"
    DETECTOR_STOPPED = "detector_stopped"