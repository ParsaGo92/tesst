
import asyncio
from typing import Dict, Any, Optional
from pyrogram import Client
from config.telegram_config import API_ID, API_HASH

async def get_all_star_gifts(client=None) -> tuple[list, Optional[Dict[int, Any]]]:
    try:
        if client is None:
            async with Client(
                name="gift_detector_session",
                api_id=API_ID,
                api_hash=API_HASH,
                in_memory=True
            ) as client:
                gifts = await client.get_available_gifts()
        else:
            gifts = await client.get_available_gifts()
            
        gifts_dict = {}
        
        for gift in gifts:
            # Extract price with priority: price > star_count > stars > cost
            price = None
            for attr_name in ['price', 'star_count', 'stars', 'cost']:
                if hasattr(gift, attr_name):
                    price = getattr(gift, attr_name, 0)
                    if price and price > 0:  # Use first non-zero value
                        break
            
            # If no price found, use 0
            if price is None:
                price = 0
            
            # Extract availability data
            total_amount = getattr(gift, 'total_amount', None)
            available_amount = getattr(gift, 'available_amount', None)
            
            # Determine if limited
            is_limited = getattr(gift, 'is_limited', False)
            if not is_limited and total_amount is not None:
                is_limited = True  # If has total_amount, it's limited
            
            # Calculate sold out status
            sold_out = False
            if is_limited and available_amount is not None:
                sold_out = available_amount <= 0
            
            gift_data = {
                'id': gift.id,
                'gift_id': str(gift.id),
                'stars': price,
                'total_amount': total_amount,
                'available_amount': available_amount,
                'is_limited': is_limited,
                'sold_out': sold_out,
                'first_detected': None,
                'last_updated': None
            }
            gifts_dict[gift.id] = gift_data
        
        return gifts, gifts_dict
            
    except Exception as e:
        print(f"Error getting star gifts: {e}")
        return [], None