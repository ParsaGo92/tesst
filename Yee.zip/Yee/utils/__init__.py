"""
Utility Functions
Common helpers and tools
"""