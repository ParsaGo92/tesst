#!/usr/bin/env python3

import asyncio
import aiosqlite
import os

async def cleanup_database():

    db_path = "user_data.db"
    
    if os.path.exists(db_path):
        async with aiosqlite.connect(db_path) as db:

            await db.execute("DELETE FROM user_settings WHERE user_id = 1234567890")
            await db.commit()
            

            cursor = await db.execute("SELECT user_id, autobuy_enabled FROM user_settings")
            rows = await cursor.fetchall()
            
            print(f"Database cleaned. Remaining users: {len(rows)}")
            for row in rows:
                print(f"User ID: {row[0]}, AutoBuy: {row[1]}")

if __name__ == "__main__":
    asyncio.run(cleanup_database())