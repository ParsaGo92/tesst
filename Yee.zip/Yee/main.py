#!/usr/bin/env python3
import asyncio
import os

async def main():

    print("Gift Detector Service")
    print("===================")
    

    os.environ["API_ID"] = "28135459"
    os.environ["API_HASH"] = "ffb0975a70486423176252f6a004e5a2"
    

    api_id = os.getenv("API_ID")
    api_hash = os.getenv("API_HASH")
    
    if not api_id or not api_hash:
        print("⚠️  API_ID and API_HASH environment variables are required for gift detection")
        print("🤖 Bot functionality will work without these, but real-time gift detection is disabled")
        print("📝 Please provide API_ID and API_HASH to enable full gift detection")
        

        try:
            while True:
                print("⏱️  Gift detector waiting for API credentials...")
                await asyncio.sleep(60)
        except KeyboardInterrupt:
            print("🛑 Gift detector service stopped")
        return
    

    try:
        from gift.detector import GiftDetector
        detector = GiftDetector()
        print("🚀 Starting gift detector with real API...")
        

        try:
            await detector.start()
            print("⚠️ Gift detector monitoring loop ended unexpectedly")
                
        except Exception as auth_error:
            if "phone number" in str(auth_error).lower() or "auth" in str(auth_error).lower():
                print("⚠️  Authentication required for Telegram API")
                print("📱 Please provide phone number for Telegram authentication")
                print("🔄 Gift detector will work in fallback mode for now")
                

                while True:
                    print("⏳ Gift detector running in fallback mode...")
                    await asyncio.sleep(300)
            else:
                raise auth_error
                
    except KeyboardInterrupt:
        print("🛑 Stopping gift detector...")
        if 'detector' in locals():
            await detector.stop()
    except Exception as e:
        print(f"❌ Error running gift detector: {e}")
        print("🔄 Continuing in monitoring mode...")
        
    
        try:
            while True:
                print("⏳ Gift detector monitoring (API connection issues)...")
                await asyncio.sleep(300)
        except KeyboardInterrupt:
            print("🛑 Service stopped")

if __name__ == "__main__":
    asyncio.run(main())