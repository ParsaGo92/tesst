# Gift AutoBuyer Bot - Replit Configuration

## Overview

A Telegram bot system that automatically monitors and purchases limited-time gifts using Telegram's star currency. The bot provides users with real-time gift detection, configurable filters, and automated purchasing capabilities. The system consists of multiple components including a Telegram bot interface, gift detection service, payment processing, and user management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Core Technology**: Aiogram v3 (asynchronous Telegram bot framework)
- **Handler Structure**: Modular router-based architecture with separate handlers for main commands, payments, and gift browsing
- **State Management**: FSM (Finite State Machine) for managing multi-step user interactions
- **Authentication**: Hardcoded authorized user IDs for access control

### Gift Detection System
- **Primary Detection**: Pyrogram client for real-time Telegram API access to monitor gift availability
- **Fallback System**: Bot API detector when user authentication fails
- **Data Processing**: Custom gift parsing system that extracts pricing, availability, and limitation status
- **Event System**: Publisher-subscriber pattern for real-time gift updates

### Database Layer
- **Technology**: SQLite with aiosqlite for async operations
- **User Data**: Stores user preferences, balances, filter settings, and purchase history
- **Schema**: Single table design with user settings including star balance, autobuy status, and price filters

### Auto-Purchase Engine
- **Real-time Processing**: Event-driven architecture that triggers on new gift detection
- **Filter System**: Configurable price ranges, limited gift preferences, and purchase limits per cycle
- **Gift Sender**: Wrapper around Telegram's gift API with error handling and retry logic
- **Sync Manager**: File-based gift synchronization with callback listeners

### Data Storage
- **Gift Data**: JSON file-based storage for gift information and historical data
- **User Sessions**: Pyrogram session files for maintaining Telegram API connections
- **Clean Data Management**: Structured gift data manager preventing duplicates and maintaining consistency

### Payment Integration
- **Telegram Stars**: Native Telegram star currency for gift purchases
- **Payment Flow**: Multi-step payment process with validation and confirmation
- **Error Handling**: Comprehensive error handling for insufficient funds, API errors, and transaction failures

### User Interface
- **Inline Keyboards**: Rich interactive menus for all bot operations
- **Pagination**: Efficient gift browsing with paginated displays
- **Real-time Updates**: Dynamic message updates for live status information
- **Markdown Formatting**: Structured message formatting with proper escaping

### Monitoring and Logging
- **Colored Logging**: Priority-based colored console output for different gift values
- **Event Tracking**: Comprehensive event logging for user actions and system operations
- **Performance Metrics**: Uptime tracking, scan counts, and success rates
- **Error Reporting**: Detailed error logging with context information

## External Dependencies

### Telegram APIs
- **Bot API**: Core bot functionality through aiogram framework
- **User API**: Gift detection via Pyrogram client for real-time monitoring
- **Payment API**: Telegram Stars payment processing

### Python Libraries
- **aiogram**: Modern Telegram bot framework with async support
- **pyrogram**: Telegram MTProto API client for advanced operations
- **aiosqlite**: Async SQLite database operations
- **aiofiles**: Async file I/O operations

### Configuration Management
- **Environment Variables**: API credentials and configuration parameters
- **Settings Module**: Centralized configuration with defaults and validation
- **Session Management**: Telegram session persistence for API connections

### Data Persistence
- **SQLite Database**: User data and settings storage
- **JSON Files**: Gift data and historical information
- **File System**: Session data and temporary files storage