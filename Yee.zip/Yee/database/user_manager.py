
import json
import aiosqlite
import asyncio
from typing import Dict, Any, Optional
from pathlib import Path

class UserDataManager:
    def __init__(self, db_path: str = "data/users.db"):
        self.db_path = db_path
        
    async def init_db(self):

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS user_settings (
                    user_id INTEGER PRIMARY KEY,
                    stars_balance INTEGER DEFAULT 0,
                    autobuy_enabled BOOLEAN DEFAULT FALSE,
                    filter_enabled BOOLEAN DEFAULT TRUE,
                    max_price_limit INTEGER DEFAULT 10000,
                    min_price_limit INTEGER DEFAULT 0,
                    max_buy_per_cycle INTEGER DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            try:
                await db.execute("ALTER TABLE user_settings ADD COLUMN min_price_limit INTEGER DEFAULT 0")
                await db.commit()
            except Exception:
                pass
            
            await db.commit()
    
    async def get_user_data(self, user_id: int) -> Dict[str, Any]:

        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM user_settings WHERE user_id = ?", 
                (user_id,)
            )
            row = await cursor.fetchone()
            
            if row:
                columns = [desc[0] for desc in cursor.description]
                return dict(zip(columns, row))
            else:

                await db.execute("""
                    INSERT OR IGNORE INTO user_settings (user_id, autobuy_enabled) VALUES (?, FALSE)
                """, (user_id,))
                await db.commit()
                

                cursor = await db.execute(
                    "SELECT * FROM user_settings WHERE user_id = ?", 
                    (user_id,)
                )
                row = await cursor.fetchone()
                columns = [desc[0] for desc in cursor.description]
                return dict(zip(columns, row))
    
    async def update_user_setting(self, user_id: int, field: str, value: Any):

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(f"""
                UPDATE user_settings 
                SET {field} = ?, updated_at = CURRENT_TIMESTAMP 
                WHERE user_id = ?
            """, (value, user_id))
            await db.commit()
    
    async def add_stars(self, user_id: int, amount: int):

        user_data = await self.get_user_data(user_id)
        new_balance = user_data['stars_balance'] + amount
        await self.update_user_setting(user_id, 'stars_balance', new_balance)
        return new_balance
    
    async def spend_stars(self, user_id: int, amount: int) -> bool:

        user_data = await self.get_user_data(user_id)
        if user_data['stars_balance'] >= amount:
            new_balance = user_data['stars_balance'] - amount
            await self.update_user_setting(user_id, 'stars_balance', new_balance)
            return True
        return False
    
    async def toggle_autobuy(self, user_id: int) -> bool:

        user_data = await self.get_user_data(user_id)
        new_state = not user_data['autobuy_enabled']
        await self.update_user_setting(user_id, 'autobuy_enabled', new_state)
        return new_state
    
    async def toggle_filter(self, user_id: int) -> bool:
        """Toggle filter setting, return new state"""
        user_data = await self.get_user_data(user_id)
        new_state = not user_data['filter_enabled']
        await self.update_user_setting(user_id, 'filter_enabled', new_state)
        return new_state
    
    async def get_all_autobuy_users(self) -> list:
        """Get all users with autobuy enabled"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM user_settings WHERE autobuy_enabled = TRUE"
            )
            rows = await cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in rows]

user_data_manager = UserDataManager()