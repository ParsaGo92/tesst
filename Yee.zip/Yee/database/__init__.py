"""
Database Management
Handles user data and database operations
"""