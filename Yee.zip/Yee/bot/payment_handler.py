
import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.user_manager import user_data_manager
from bot.keyboards import get_main_keyboard, get_cancel_keyboard

logger = logging.getLogger(__name__)


class PaymentState(StatesGroup):
    waiting_for_payment_amount = State()


payment_router = Router()


STAR_PACKAGES = [
    {"stars": 100, "price": 130, "title": "100 Stars", "description": "Basic star package"},
    {"stars": 500, "price": 650, "title": "500 Stars", "description": "Popular star package"},
    {"stars": 1000, "price": 1300, "title": "1000 Stars", "description": "Premium star package"},
    {"stars": 2500, "price": 3250, "title": "2500 Stars", "description": "Ultimate star package"},
]

@payment_router.callback_query(F.data == "real_charge_stars")
async def handle_real_charge_stars(callback: CallbackQuery, state: FSMContext):

    await state.set_state(PaymentState.waiting_for_payment_amount)
    
    try:
        await callback.message.edit_text(
            "Enter the number of stars to purchase:\n\n"
            "Rate: 1 star = 1.3 XTR\n"
            "Minimum: 10 stars",
            reply_markup=get_cancel_keyboard()
        )
    except Exception:
        await callback.message.answer(
            "Enter the number of stars to purchase:\n\n"
            "Rate: 1 star = 1.3 XTR\n"
            "Minimum: 10 stars",
            reply_markup=get_cancel_keyboard()
        )
    
    await callback.answer()

@payment_router.message(PaymentState.waiting_for_payment_amount)
async def process_payment_amount(message: Message, state: FSMContext):

    try:
        star_amount = int(message.text)
        
        if star_amount < 10:
            await message.answer("Minimum 10 stars required.")
            return
        
        if star_amount > 10000:
            await message.answer("Maximum 10000 stars per transaction.")
            return
        
        prices = [LabeledPrice(label=f"{star_amount} Telegram Stars", amount=star_amount)]
        
        await message.answer_invoice(
            title=f"Purchase {star_amount} Stars",
            description=f"Add {star_amount} Telegram Stars to your balance",
            prices=prices,
            provider_token="",
            payload=f"stars_{star_amount}_{message.from_user.id}",
            currency="XTR"
        )
        

        
        await state.clear()
        
    except ValueError:
        await message.answer("Please enter a valid number.")
    except Exception as e:
        logger.error(f"Failed to create invoice: {e}")
        await message.answer(
            "Payment system temporarily unavailable.",
            reply_markup=get_main_keyboard()
        )

@payment_router.pre_checkout_query()
async def handle_pre_checkout_query(pre_checkout_query: PreCheckoutQuery):

    try:
        payload_parts = pre_checkout_query.invoice_payload.split("_")
        if len(payload_parts) != 3 or payload_parts[0] != "stars":
            await pre_checkout_query.answer(ok=False, error_message="Invalid payment")
            return
        
        star_amount = int(payload_parts[1])
        user_id = int(payload_parts[2])
        
        if star_amount < 10 or star_amount > 10000:
            await pre_checkout_query.answer(ok=False, error_message="Invalid star amount")
            return
        
        await pre_checkout_query.answer(ok=True)
        
    except Exception as e:
        logger.error(f"Pre-checkout error: {e}")
        await pre_checkout_query.answer(ok=False, error_message="Payment validation failed")

@payment_router.message(F.successful_payment)
async def handle_successful_payment(message: Message):

    try:
        payment = message.successful_payment
        payload_parts = payment.invoice_payload.split("_")
        
        if len(payload_parts) != 3 or payload_parts[0] != "stars":
            await message.answer("Payment processed but validation failed. Contact support.")
            return
        
        star_amount = int(payload_parts[1])
        user_id = int(payload_parts[2])
        
        new_balance = await user_data_manager.add_stars(user_id, star_amount)
        
        await message.answer(
            f"Payment successful!\n"
            f"Added {star_amount} stars\n"
            f"New balance: {new_balance} stars\n"
            f"ID: {payment.telegram_payment_charge_id}"
        )
        
        logger.info(f"Successful payment: User {user_id} purchased {star_amount} stars")
        
    except Exception as e:
        logger.error(f"Payment processing error: {e}")
        await message.answer(
            "Payment received but processing failed. Contact support with your transaction details.",
            reply_markup=get_main_keyboard()
        )