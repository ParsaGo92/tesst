
import re

def escape_markdown_v2(text: str) -> str:


    escape_chars = r'_*[]()~`>#+-=|{}.!'
    

    for char in escape_chars:
        text = text.replace(char, f'\\{char}')
    
    return text

def format_main_menu(balance: int, autobuy_status: str, filter_status: str) -> str:

    return f"""*🎛 Gift AutoBuyer*

*Balance:* `{balance}` stars
*AutoBuy:* `{autobuy_status}`
*Filter:* `{filter_status}`

_Select an option below:_"""

def format_balance_view(balance: int, autobuy: str, filter_status: str, min_price: int, max_price: int, max_cycle: int) -> str:

    return f"""*💰 Your Balance & Settings*

*Current Balance:* `{balance}` stars

*Settings:*
• *AutoBuy:* `{autobuy}`
• *Filter:* `{filter_status}`
• *Min Price:* `{min_price:,}` stars
• *Max Price:* `{max_price:,}` stars
• *Max Per Cycle:* `{max_cycle}`

_Manage your automated purchases below_"""

def format_filter_settings(limited_status: str, min_price: int, max_price: int, max_cycle: int) -> str:

    return f"""*🔍 Filter Settings*

*Current Configuration:*
• *Limited Gifts Only:* `{limited_status}`
• *Min Price Per Gift:* `{min_price:,}` stars
• *Max Price Per Gift:* `{max_price:,}` stars
• *Max Buys Per Cycle:* `{max_cycle}`

_Configure your purchase filters below\\._"""

def format_gift_details(gift_id: str, stars: int, available: int, is_limited: bool, user_balance: int) -> str:

    gift_type = "Limited" if is_limited else "Unlimited"
    short_id = gift_id[-4:] if len(gift_id) > 4 else gift_id
    
    return f"""*🎁 Gift Details*

• *Gift ID:* `#{short_id}`
• *Price:* `{stars}` stars
• *Available:* `{available if is_limited else "Unlimited"}`
• *Type:* `{gift_type}`

*Your Balance:* `{user_balance}` stars

_Do you want to purchase this gift?_"""

def format_available_gifts(gifts_count: int, page: int, total_pages: int, filter_status: str, max_price: int, balance: int) -> str:

    return f"""*🎁 Available Gifts* \\({gifts_count} found\\)

*Page {page} of {total_pages}*

*Your Settings:*
• *Filter Limited:* `{filter_status}`
• *Max Price:* `{max_price:,}` stars
• *Balance:* `{balance}` stars

_Select a gift to view details:_"""

def format_no_gifts_found(filter_status: str, max_price: int, balance: int) -> str:

    return f"""*🔍 No Available Gifts Found*

*Current Settings:*
• *Balance:* `{balance}` stars
• *Max Price:* `{max_price:,}` stars
• *Limited Filter:* `{filter_status}`

_Try adjusting your filters to see more gifts\\._"""

def format_purchase_success(gift_id: str, stars: int, remaining_balance: int) -> str:

    short_id = gift_id[-4:] if len(gift_id) > 4 else gift_id
    
    return f"""*✅ Purchase Confirmed\\!*

• *Gift:* `#{short_id}`
• *Spent:* `{stars}` stars
• *Remaining:* `{remaining_balance}` stars

_Gift sent successfully\\!_"""

def format_insufficient_stars(needed: int, current: int) -> str:

    return f"""*⚠️ Not Enough Stars*

You need `{needed}` stars, but you only have `{current}`\\.

_Add more stars to continue\\._"""

def format_charge_stars_prompt(current_balance: int) -> str:

    return f"""*💠 Charge Stars*

**Enter adad**

_Current balance:_ *{current_balance} ⭐*"""

def format_stars_added(amount: int) -> str:

    return f"""*✅ Stars Added*

Added `{amount}` stars to your balance\\.

_You can now make purchases\\._"""

def format_autobuy_toggled(status: str) -> str:

    return f"""*🔄 AutoBuy*

AutoBuy: `{status}`

_Setting updated\\._"""

def format_filter_toggled(status: str) -> str:

    return f"""*🔍 Filter Updated*

Limited filter: `{status}`

_Filter settings updated\\._"""

def format_price_set(price: int) -> str:

    return f"""*💰 Max Price Updated*

Max price set to `{price:,}` stars

_Price limit updated successfully\\._"""

def format_cycle_set(cycle: int) -> str:

    return f"""*🔄 Max Cycle Updated*

Max per cycle set to `{cycle}`

_Cycle limit updated successfully\\._"""