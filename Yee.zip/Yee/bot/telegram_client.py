"""
Client Manager - Shared Pyrogram client access
"""
from typing import Optional
from pyrogram import Client

# Global client reference
_shared_client: Optional[Client] = None

def set_shared_client(client: Client):
    """Set the shared Pyrogram client"""
    global _shared_client
    _shared_client = client

def get_shared_client() -> Optional[Client]:
    """Get the shared Pyrogram client"""
    return _shared_client

def has_client() -> bool:
    """Check if client is available"""
    return _shared_client is not None