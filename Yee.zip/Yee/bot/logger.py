
import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional
from aiogram.types import Message, CallbackQuery, User

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    GRAY = '\033[90m'
    END = '\033[0m'

class BotLogger:
    def __init__(self, name: str = "Gift AutoBuyer Bot"):
        self.name = name
        self.start_time = time.time()
        self.stats = {
            'total_users': 0,
            'active_sessions': 0,
            'commands_processed': 0,
            'buttons_clicked': 0,
            'purchases_made': 0,
            'errors_occurred': 0,
            'stars_charged': 0,
            'gifts_browsed': 0
        }
        self.logger = logging.getLogger(name)
        
    def get_uptime(self) -> str:

        uptime_seconds = int(time.time() - self.start_time)
        hours = uptime_seconds // 3600
        minutes = (uptime_seconds % 3600) // 60
        seconds = uptime_seconds % 60
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    
    def get_timestamp(self) -> str:

        return datetime.now().strftime("%H:%M:%S")
    
    def format_user_info(self, user: User) -> str:

        username = f"@{user.username}" if user.username else "No username"
        return f"User {user.id} ({user.first_name} {user.last_name or ''}) {username}"
    
    def log_bot_startup(self):

        print(f"\n{Colors.CYAN}{'='*80}{Colors.END}")
        print(f"{Colors.CYAN}{Colors.BOLD}🤖 GIFT AUTOBUYER BOT - MONITORING SYSTEM{Colors.END}")
        print(f"{Colors.CYAN}{'='*80}{Colors.END}")
        print(f"{Colors.GREEN}🚀 [{self.get_timestamp()}] Bot started successfully{Colors.END}")
        print(f"{Colors.BLUE}📊 Monitoring: Users, Commands, Purchases, Errors{Colors.END}")
        print(f"{Colors.YELLOW}⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.END}")
        print(f"{Colors.CYAN}{'='*80}{Colors.END}\n")
        
    def log_user_action(self, action_type: str, user: User, details: str = "", success: bool = True):

        user_info = self.format_user_info(user)
        timestamp = self.get_timestamp()
        status_icon = "✅" if success else "❌"
        color = Colors.GREEN if success else Colors.RED
        
        if action_type == "command":
            self.stats['commands_processed'] += 1
            print(f"{color}{status_icon} [{timestamp}] COMMAND | {user_info}{Colors.END}")
            if details:
                print(f"{Colors.GRAY}   └─ {details}{Colors.END}")
                
        elif action_type == "button":
            self.stats['buttons_clicked'] += 1
            print(f"{color}{status_icon} [{timestamp}] BUTTON | {user_info}{Colors.END}")
            if details:
                print(f"{Colors.GRAY}   └─ Action: {details}{Colors.END}")
                
        elif action_type == "purchase":
            self.stats['purchases_made'] += 1
            print(f"{Colors.PURPLE}💎 [{timestamp}] PURCHASE | {user_info}{Colors.END}")
            if details:
                print(f"{Colors.GRAY}   └─ {details}{Colors.END}")
                
        elif action_type == "charge":
            self.stats['stars_charged'] += 1
            print(f"{Colors.YELLOW}⭐ [{timestamp}] CHARGE | {user_info}{Colors.END}")
            if details:
                print(f"{Colors.GRAY}   └─ {details}{Colors.END}")
                
        elif action_type == "browse":
            self.stats['gifts_browsed'] += 1
            print(f"{Colors.CYAN}🛍️ [{timestamp}] BROWSE | {user_info}{Colors.END}")
            if details:
                print(f"{Colors.GRAY}   └─ {details}{Colors.END}")
                
    def log_error(self, error_type: str, user: Optional[User], error_msg: str, details: str = ""):

        self.stats['errors_occurred'] += 1
        timestamp = self.get_timestamp()
        user_info = self.format_user_info(user) if user else "System"
        
        print(f"{Colors.RED}❌ [{timestamp}] ERROR | {user_info}{Colors.END}")
        print(f"{Colors.RED}   Type: {error_type}{Colors.END}")
        print(f"{Colors.RED}   Message: {error_msg}{Colors.END}")
        if details:
            print(f"{Colors.RED}   Details: {details}{Colors.END}")
        print()
        
    def log_system_stats(self, interval_minutes: int = 5):

        uptime = self.get_uptime()
        timestamp = self.get_timestamp()
        
        print(f"\n{Colors.BLUE}{'─'*60}{Colors.END}")
        print(f"{Colors.BLUE}{Colors.BOLD}📊 SYSTEM STATUS | {timestamp} | Uptime: {uptime}{Colors.END}")
        print(f"{Colors.BLUE}{'─'*60}{Colors.END}")
        print(f"{Colors.GREEN}👥 Total Users: {self.stats['total_users']}{Colors.END}")
        print(f"{Colors.CYAN}🔥 Active Sessions: {self.stats['active_sessions']}{Colors.END}")
        print(f"{Colors.YELLOW}⚡ Commands: {self.stats['commands_processed']}{Colors.END}")
        print(f"{Colors.PURPLE}🖱️  Buttons: {self.stats['buttons_clicked']}{Colors.END}")
        print(f"{Colors.GREEN}💎 Purchases: {self.stats['purchases_made']}{Colors.END}")
        print(f"{Colors.YELLOW}⭐ Stars Charged: {self.stats['stars_charged']}{Colors.END}")
        print(f"{Colors.CYAN}🛍️ Gifts Browsed: {self.stats['gifts_browsed']}{Colors.END}")
        print(f"{Colors.RED}❌ Errors: {self.stats['errors_occurred']}{Colors.END}")
        print(f"{Colors.BLUE}{'─'*60}{Colors.END}\n")
        
    def log_autobuy_activity(self, user_count: int, gifts_found: int, purchases_made: int):

        timestamp = self.get_timestamp()
        if purchases_made > 0:
            print(f"{Colors.PURPLE}🤖 [{timestamp}] AUTOBUY | {user_count} users checked, {gifts_found} gifts, {purchases_made} purchases{Colors.END}")
        else:
            print(f"{Colors.GRAY}🤖 [{timestamp}] AUTOBUY | {user_count} users checked, {gifts_found} gifts available{Colors.END}")
            
    def log_gift_monitor_activity(self, gifts_monitored: int, new_gifts: int = 0):

        timestamp = self.get_timestamp()
        if new_gifts > 0:
            print(f"{Colors.GREEN}🔍 [{timestamp}] MONITOR | {gifts_monitored} gifts tracked, {new_gifts} NEW GIFTS DETECTED!{Colors.END}")
        else:
            print(f"{Colors.GRAY}🔍 [{timestamp}] MONITOR | {gifts_monitored} gifts tracked, no new gifts{Colors.END}")
            
    def log_user_session(self, action: str, user: User, session_data: Dict[str, Any] = None):

        timestamp = self.get_timestamp()
        user_info = self.format_user_info(user)
        
        if action == "start":
            self.stats['active_sessions'] += 1
            print(f"{Colors.GREEN}🚀 [{timestamp}] SESSION START | {user_info}{Colors.END}")
            if session_data:
                print(f"{Colors.GRAY}   └─ Balance: {session_data.get('balance', 0)} stars{Colors.END}")
                
        elif action == "settings":
            print(f"{Colors.CYAN}⚙️ [{timestamp}] SETTINGS | {user_info}{Colors.END}")
            if session_data:
                print(f"{Colors.GRAY}   └─ AutoBuy: {session_data.get('autobuy', 'Off')}, Filter: {session_data.get('filter', 'Off')}{Colors.END}")
                
    def log_performance_metrics(self, response_time_ms: float, operation: str):

        if response_time_ms > 1000:
            color = Colors.RED if response_time_ms > 2000 else Colors.YELLOW
            print(f"{color}⏱️ [{self.get_timestamp()}] SLOW {operation}: {response_time_ms:.1f}ms{Colors.END}")


bot_logger = BotLogger()

def log_command(message: Message, command: str, success: bool = True):

    bot_logger.log_user_action("command", message.from_user, f"/{command}", success)

def log_button_click(callback: CallbackQuery, action: str, success: bool = True):

    bot_logger.log_user_action("button", callback.from_user, action, success)

def log_purchase(user: User, gift_id: str, stars: int, success: bool = True):

    details = f"Gift {gift_id[-4:]} - {stars} stars"
    bot_logger.log_user_action("purchase", user, details, success)

def log_charge(user: User, amount: int, success: bool = True):

    details = f"Added {amount} stars"
    bot_logger.log_user_action("charge", user, details, success)

def log_browse(user: User, page: int, total_gifts: int):

    details = f"Page {page}, {total_gifts} gifts available"
    bot_logger.log_user_action("browse", user, details, True)

def log_bot_error(error_type: str, user: Optional[User], error_msg: str, details: str = ""):

    bot_logger.log_error(error_type, user, error_msg, details)

def log_system_status():

    bot_logger.log_system_stats()

def log_startup():

    bot_logger.log_bot_startup()

def log_autobuy(user_count: int, gifts_found: int, purchases_made: int):

    bot_logger.log_autobuy_activity(user_count, gifts_found, purchases_made)

def log_monitor(gifts_monitored: int, new_gifts: int = 0):

    bot_logger.log_gift_monitor_activity(gifts_monitored, new_gifts)

def update_user_count(count: int):

    bot_logger.stats['total_users'] = count