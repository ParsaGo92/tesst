
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_main_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="View Balance", callback_data="view_balance")
        ],
        [
            InlineKeyboardButton(text="Settings", callback_data="filter_settings"),
            InlineKeyboardButton(text="Available Gifts", callback_data="view_available_gifts")
        ],
        [
            InlineKeyboardButton(text="Toggle AutoBuy", callback_data="toggle_autobuy"),
            InlineKeyboardButton(text="Charge Stars", callback_data="real_charge_stars")
        ]
    ])

def get_cancel_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Cancel", callback_data="cancel")]
    ])

def get_filter_settings_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Filter Limited Gifts", callback_data="toggle_limited_filter")
        ],
        [
            InlineKeyboardButton(text="Min Price", callback_data="set_min_price_menu"),
            InlineKeyboardButton(text="Max Price", callback_data="set_max_price_menu")
        ],
        [
            InlineKeyboardButton(text="Max Gifts Per Cycle", callback_data="set_max_cycle_menu")
        ],
        [
            InlineKeyboardButton(text="Back", callback_data="back_to_menu")
        ]
    ])

def get_max_price_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="15⭐", callback_data="set_price:15"),
            InlineKeyboardButton(text="50⭐", callback_data="set_price:50"),
            InlineKeyboardButton(text="100⭐", callback_data="set_price:100")
        ],
        [
            InlineKeyboardButton(text="500⭐", callback_data="set_price:500"),
            InlineKeyboardButton(text="1K⭐", callback_data="set_price:1000"),
            InlineKeyboardButton(text="5K⭐", callback_data="set_price:5000")
        ],
        [
            InlineKeyboardButton(text="10K⭐", callback_data="set_price:10000"),
            InlineKeyboardButton(text="No Limit", callback_data="set_price:999999")
        ],
        [
            InlineKeyboardButton(text="Back", callback_data="filter_settings")
        ]
    ])

def get_max_cycle_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="1", callback_data="set_cycle:1"),
            InlineKeyboardButton(text="2", callback_data="set_cycle:2"),
            InlineKeyboardButton(text="5", callback_data="set_cycle:5")
        ],
        [
            InlineKeyboardButton(text="10", callback_data="set_cycle:10"),
            InlineKeyboardButton(text="15", callback_data="set_cycle:15"),
            InlineKeyboardButton(text="25", callback_data="set_cycle:25")
        ],
        [
            InlineKeyboardButton(text="50", callback_data="set_cycle:50"),
            InlineKeyboardButton(text="100", callback_data="set_cycle:100"),
            InlineKeyboardButton(text="150", callback_data="set_cycle:150")
        ],
        [
            InlineKeyboardButton(text="Back", callback_data="filter_settings")
        ]
    ])

def get_min_price_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="0⭐", callback_data="set_min_price:0"),
            InlineKeyboardButton(text="10⭐", callback_data="set_min_price:10"),
            InlineKeyboardButton(text="15⭐", callback_data="set_min_price:15")
        ],
        [
            InlineKeyboardButton(text="50⭐", callback_data="set_min_price:50"),
            InlineKeyboardButton(text="100⭐", callback_data="set_min_price:100"),
            InlineKeyboardButton(text="500⭐", callback_data="set_min_price:500")
        ],
        [
            InlineKeyboardButton(text="1K⭐", callback_data="set_min_price:1000"),
            InlineKeyboardButton(text="5K⭐", callback_data="set_min_price:5000")
        ],
        [
            InlineKeyboardButton(text="Back", callback_data="filter_settings")
        ]
    ])