
import asyncio
import logging
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config.settings import BOT_TOKEN
from bot.main_handlers import router
from bot.payment_handler import payment_router
from gift.browser import browser_router

from database.user_manager import user_data_manager
from gift.auto_buyer import get_autobuy_task
from gift.monitor import get_gift_monitor
from bot.logger import log_startup, log_system_status



logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

async def main():

    try:

        bot = Bot(
            token=BOT_TOKEN,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML)
        )
        dp = Dispatcher()
        

        dp.include_router(router)
        dp.include_router(payment_router)
        dp.include_router(browser_router)

        

        log_startup()
        

        await user_data_manager.init_db()
        logger.info("Database initialized")
        

        autobuy_task = get_autobuy_task(bot)
        await autobuy_task.start()
        logger.info("AutoBuy task started")
        

        gift_monitor = get_gift_monitor(bot)
        await gift_monitor.start()
        logger.info("Gift monitor started")
        

        
        from bot.telegram_client import get_shared_client
        await asyncio.sleep(5)
        client = get_shared_client()
        if client:
            logger.info("Shared Pyrogram client is available for gift sending")
        else:
            logger.warning("No shared Pyrogram client available yet - gift sending may not work")
        

        logger.info("Bot starting...")
        

        async def periodic_status():
            while True:
                await asyncio.sleep(300)
                log_system_status()
        

        asyncio.create_task(periodic_status())
        
        await dp.start_polling(bot)
        
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Error running bot: {e}")
    finally:

        if 'autobuy_task' in locals():
            await autobuy_task.stop()
        if 'gift_monitor' in locals():
            await gift_monitor.stop()
        if 'bot' in locals():
            await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())